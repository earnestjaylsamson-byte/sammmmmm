<?php

require_once "config.php";
requireVerifiedResident($conn);

ensureRequestColumns($conn);

$message = "";
$errors  = [];

$prices = documentCatalog();

// Form values (kept on screen when something is wrong)
$v = [
    "full_name"      => $_SESSION["user_name"] ?? "",
    "age"            => "",
    "sex"            => "",
    "civil_status"   => "",
    "contact_number" => "",
    "address"        => "",
    "document_type"  => "",
    "purpose"        => ""
];

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    foreach ($v as $key => $default) {
        $v[$key] = trim($_POST[$key] ?? "");
    }

    if ($v["full_name"] === "") { $errors["full_name"] = "Full name is required."; }

    if ($v["age"] === "") {
        $errors["age"] = "Age is required.";
    } elseif (!ctype_digit($v["age"]) || (int)$v["age"] < 1 || (int)$v["age"] > 120) {
        $errors["age"] = "Enter a valid age (1-120).";
    }

    if (!in_array($v["sex"], ["Male", "Female"], true)) { $errors["sex"] = "Please select your sex."; }

    if (!in_array($v["civil_status"], ["Single", "Married", "Widowed", "Separated"], true)) {
        $errors["civil_status"] = "Please select your civil status.";
    }

    $phone = preg_replace("/[\s-]/", "", $v["contact_number"]);
    if ($v["contact_number"] === "") {
        $errors["contact_number"] = "Contact number is required.";
    } elseif (!preg_match("/^(09\d{9}|\+639\d{9})$/", $phone)) {
        $errors["contact_number"] = "Use a valid mobile number, e.g. 09123456789.";
    }

    if ($v["address"] === "") { $errors["address"] = "Address is required."; }

    if ($v["document_type"] === "") {
        $errors["document_type"] = "Please choose a document.";
    } elseif (!isset($prices[$v["document_type"]])) {
        $errors["document_type"] = "Invalid document type.";
    }

    if ($v["purpose"] === "") { $errors["purpose"] = "Please state the purpose."; }

    if (empty($errors)) {

        $document_type  = $v["document_type"];
        $purpose        = $v["purpose"];
        $amount         = $prices[$document_type];
        $user_id        = $_SESSION["user_id"];
        $request_number = generateRequestNumber();
        $status         = "Pending";
        $payment_status = $amount > 0 ? "Pending" : "Not Required";
        $age            = (int)$v["age"];

        $stmt = $conn->prepare("
            INSERT INTO document_requests
            (request_number, user_id, document_type, purpose, amount, status, payment_status,
             full_name, age, sex, civil_status, contact_number, address)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        if (!$stmt) {
            die("SQL PREPARE ERROR: " . $conn->error);
        }

        $stmt->bind_param(
            "sissdsssissss",
            $request_number, $user_id, $document_type, $purpose, $amount, $status, $payment_status,
            $v["full_name"], $age, $v["sex"], $v["civil_status"], $phone, $v["address"]
        );

        if ($stmt->execute()) {
            $new_request_id = $stmt->insert_id;
            header("Location: view_request.php?id=" . $new_request_id);
            exit();
        } else {
            $message = "Could not save your request: " . $stmt->error;
        }

        $stmt->close();
    }
}

function fieldError($errors, $key) {
    return isset($errors[$key]) ? '<div class="field-error">' . htmlspecialchars($errors[$key]) . '</div>' : '';
}
function bad($errors, $key) {
    return isset($errors[$key]) ? ' invalid' : '';
}
function sel($current, $value) {
    return $current === $value ? " selected" : "";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Request Document - Barangay Mabuhay</title>

<link rel="icon" type="image/png" href="favicon.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="style.css?v=<?= @filemtime(__DIR__ . '/style.css') ?>">
<script src="form.js?v=<?= @filemtime(__DIR__ . '/form.js') ?>" defer></script>
</head>

<body class="narrow">

<?php include "nav.php"; ?>

<div class="container">

    <div class="box">

        <h1>Request a Document</h1>
        <p class="subtitle">Fill in your information and choose the document you need.</p>

        <?php if ($message !== ""): ?>
            <div class="message error"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <form method="POST" novalidate data-validate>

            <div class="form-section">Personal Information</div>

            <label for="full_name">Full Name</label>
            <input type="text" id="full_name" name="full_name" class="<?= bad($errors, 'full_name') ?>"
                   placeholder="Juan Dela Cruz" data-label="Full name" required
                   value="<?= htmlspecialchars($v['full_name']) ?>">
            <?= fieldError($errors, 'full_name') ?>

            <div class="form-row">
                <div>
                    <label for="age">Age</label>
                    <input type="number" id="age" name="age" min="1" max="120" class="<?= bad($errors, 'age') ?>"
                           placeholder="e.g. 25" data-rule="age" data-label="Age" required
                           value="<?= htmlspecialchars($v['age']) ?>">
                    <?= fieldError($errors, 'age') ?>
                </div>
                <div>
                    <label for="sex">Sex</label>
                    <select id="sex" name="sex" class="<?= bad($errors, 'sex') ?>" data-label="Sex" required>
                        <option value="">-- Select --</option>
                        <option value="Male"<?= sel($v['sex'], 'Male') ?>>Male</option>
                        <option value="Female"<?= sel($v['sex'], 'Female') ?>>Female</option>
                    </select>
                    <?= fieldError($errors, 'sex') ?>
                </div>
            </div>

            <div class="form-row">
                <div>
                    <label for="civil_status">Civil Status</label>
                    <select id="civil_status" name="civil_status" class="<?= bad($errors, 'civil_status') ?>" data-label="Civil status" required>
                        <option value="">-- Select --</option>
                        <?php foreach (["Single", "Married", "Widowed", "Separated"] as $cs): ?>
                            <option value="<?= $cs ?>"<?= sel($v['civil_status'], $cs) ?>><?= $cs ?></option>
                        <?php endforeach; ?>
                    </select>
                    <?= fieldError($errors, 'civil_status') ?>
                </div>
                <div>
                    <label for="contact_number">Contact Number</label>
                    <input type="tel" id="contact_number" name="contact_number" class="<?= bad($errors, 'contact_number') ?>"
                           placeholder="09123456789" data-rule="phone" data-label="Contact number" required
                           value="<?= htmlspecialchars($v['contact_number']) ?>">
                    <?= fieldError($errors, 'contact_number') ?>
                </div>
            </div>

            <label for="address">Address</label>
            <input type="text" id="address" name="address" class="<?= bad($errors, 'address') ?>"
                   placeholder="Purok / Street, Barangay Mabuhay, Bansalan" data-label="Address" required
                   value="<?= htmlspecialchars($v['address']) ?>">
            <?= fieldError($errors, 'address') ?>

            <div class="form-section">Document Details</div>

            <label for="document_type">Document Type</label>
            <select name="document_type" id="document_type" class="<?= bad($errors, 'document_type') ?>" data-label="Document type" required>
                <option value="">-- Select Document --</option>
                <?php foreach ($prices as $doc => $price): ?>
                    <option value="<?= htmlspecialchars($doc) ?>"<?= sel($v['document_type'], $doc) ?>>
                        <?= htmlspecialchars($doc) ?> - <?= $price > 0 ? "&#8369;" . $price : "Free" ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <?= fieldError($errors, 'document_type') ?>

            <div class="fee-hint" id="fee" hidden>
                <span>Processing fee</span>
                <strong id="feeAmount"></strong>
            </div>

            <label for="purpose">Purpose</label>
            <textarea name="purpose" id="purpose" class="<?= bad($errors, 'purpose') ?>"
                      placeholder="Enter the purpose of your request" data-label="Purpose" required><?= htmlspecialchars($v['purpose']) ?></textarea>
            <?= fieldError($errors, 'purpose') ?>

            <button type="submit">Submit Request</button>

        </form>

    </div>

</div>

<script>
var prices = <?= json_encode($prices) ?>;
var typeSelect = document.getElementById("document_type");
function showFee() {
    var fee = document.getElementById("fee");
    if (!(typeSelect.value in prices)) { fee.hidden = true; return; }
    var p = prices[typeSelect.value];
    document.getElementById("feeAmount").textContent = p > 0 ? "\u20B1" + p.toFixed(2) : "Free";
    fee.hidden = false;
}
typeSelect.addEventListener("change", showFee);
showFee();
</script>

</body>
</html>
