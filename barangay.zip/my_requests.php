<?php
require_once "config.php";
requireLogin();

$stmt = $conn->prepare("
    SELECT *
    FROM document_requests
    WHERE user_id = ?
    ORDER BY created_at DESC
");

$stmt->bind_param("i", $_SESSION["user_id"]);
$stmt->execute();

$requests = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Requests - Barangay Mabuhay</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="stylesheet" href="style.css?v=<?= @filemtime(__DIR__ . '/style.css') ?>">
</head>

<body>

<?php include "nav.php"; ?>

<div class="container">

<h1>My Document Requests</h1>

<div class="toolbar">
    <div class="search-box">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
        <input type="search" placeholder="Search by request no., document or status..." data-filter-table="myTable">
    </div>
</div>

<div class="table-box">

<table id="myTable">

<thead>
<tr>
    <th>Request No.</th>
    <th>Document</th>
    <th>Amount</th>
    <th>Status</th>
    <th>Date</th>
    <th>Action</th>
</tr>
</thead>

<tbody>

<?php if ($requests->num_rows > 0): ?>

<?php while ($row = $requests->fetch_assoc()): ?>

<tr>

<td><?php echo htmlspecialchars($row["request_number"]); ?></td>

<td><?php echo htmlspecialchars($row["document_type"]); ?></td>

<td>₱<?php echo number_format($row["amount"], 2); ?></td>

<td class="status">
<?php echo htmlspecialchars($row["status"]); ?>
</td>

<td>
<?php echo date("M d, Y", strtotime($row["created_at"])); ?>
</td>

<td>
<a
    class="view-btn"
    href="view_request.php?id=<?php echo $row["id"]; ?>"
>
View
</a>
</td>

</tr>

<?php endwhile; ?>

<?php else: ?>

<tr>
<td colspan="6" style="text-align:center;">
No document requests yet.
</td>
</tr>

<?php endif; ?>

</tbody>

</table>

</div>

</div>

<script src="ui.js?v=<?= @filemtime(__DIR__ . '/ui.js') ?>"></script>
</body>
</html>