/* Password "eye" toggle + per-field validation (only the wrong field is flagged). */
(function () {
  var EYE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>';
  var EYE_OFF = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.9 17.9A10.9 10.9 0 0 1 12 19C5 19 1 12 1 12a18.5 18.5 0 0 1 5.1-5.9M9.9 5.1A10.4 10.4 0 0 1 12 5c7 0 11 7 11 7a18.6 18.6 0 0 1-2.2 3.2M1 1l22 22"/><path d="M14.1 14.1a3 3 0 1 1-4.2-4.2"/></svg>';

  document.querySelectorAll('input[type=password]').forEach(function (input) {
    var wrap = document.createElement('div');
    wrap.className = 'pw-wrap';
    input.parentNode.insertBefore(wrap, input);
    wrap.appendChild(input);
    var btn = document.createElement('button');
    btn.type = 'button'; btn.className = 'pw-toggle'; btn.innerHTML = EYE;
    btn.setAttribute('aria-label', 'Show password');
    btn.onclick = function () {
      var show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      btn.innerHTML = show ? EYE_OFF : EYE;
      btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    };
    wrap.appendChild(btn);
  });

  function errBox(el) {
    var host = el.closest('.pw-wrap') || el;
    var n = host.nextElementSibling;
    if (!n || !n.classList.contains('field-error')) {
      n = document.createElement('div'); n.className = 'field-error';
      host.parentNode.insertBefore(n, host.nextSibling);
    }
    return n;
  }
  function check(el) {
    var v = el.value.trim(), rule = el.dataset.rule || '', msg = '';
    if (el.required && v === '') msg = (el.dataset.label || 'This field') + ' is required.';
    else if (v !== '') {
      if (rule.indexOf('email') > -1 && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) msg = 'Enter a valid email address.';
      var m = rule.match(/min:(\d+)/);
      if (m && el.value.length < +m[1]) msg = 'Use at least ' + m[1] + ' characters.';
      var mt = rule.match(/match:(#[\w-]+)/);
      if (mt && el.value !== document.querySelector(mt[1]).value) msg = 'Passwords do not match.';
      if (rule.indexOf('age') > -1 && !(+v >= 1 && +v <= 120)) msg = 'Enter a valid age (1–120).';
      if (rule.indexOf('phone') > -1 && !/^(09\d{9}|\+639\d{9})$/.test(v.replace(/[\s-]/g, ''))) msg = 'Use a valid mobile number, e.g. 09123456789.';
    }
    el.classList.toggle('invalid', !!msg);
    var box = errBox(el); box.textContent = msg;
    return !msg;
  }
  document.querySelectorAll('form[data-validate]').forEach(function (form) {
    var fields = form.querySelectorAll('[data-rule],[required]');
    fields.forEach(function (el) {
      el.addEventListener('blur', function () { if (el.value !== '' || el.classList.contains('invalid')) check(el); });
      el.addEventListener('input', function () { if (el.classList.contains('invalid')) check(el); });
      el.addEventListener('change', function () { if (el.classList.contains('invalid')) check(el); });
    });
    form.addEventListener('submit', function (e) {
      var first = null;
      fields.forEach(function (el) { if (!check(el) && !first) first = el; });
      if (first) { e.preventDefault(); first.focus(); }
    });
  });
})();
