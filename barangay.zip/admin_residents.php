<?php

require_once "config.php";
requireAdmin();
ensureUserColumns($conn);

$filters = [
    "Pending"    => "Pending Review",
    "Verified"   => "Verified",
    "Rejected"   => "Rejected",
    "Unverified" => "Not Submitted",
    "All"        => "All"
];

$filter = $_GET["filter"] ?? ($_POST["filter"] ?? "Pending");
if (!isset($filters[$filter])) { $filter = "Pending"; }

$flash = "";
$flash_type = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $action = $_POST["action"] ?? "";
    $uid    = intval($_POST["user_id"] ?? 0);
    $note   = trim($_POST["note"] ?? "");

    if ($uid > 0 && $action === "approve") {

        $stmt = $conn->prepare("UPDATE users SET verification_status = 'Verified', verified_at = NOW(), verification_note = NULL WHERE id = ? AND role = 'resident'");
        $stmt->bind_param("i", $uid);
        $stmt->execute();
        $flash = "Resident verified.";

    } elseif ($uid > 0 && $action === "reject") {

        if ($note === "") {
            $flash = "Please type a reason before rejecting.";
            $flash_type = "error";
        } else {
            $stmt = $conn->prepare("UPDATE users SET verification_status = 'Rejected', verification_note = ?, verified_at = NULL WHERE id = ? AND role = 'resident'");
            $stmt->bind_param("si", $note, $uid);
            $stmt->execute();
            $flash = "Verification rejected. The resident can submit again.";
        }
    }
}

$counts = ["All" => 0];
$res = $conn->query("SELECT verification_status, COUNT(*) AS c FROM users WHERE role = 'resident' GROUP BY verification_status");
if ($res) {
    while ($r = $res->fetch_assoc()) {
        $counts[$r["verification_status"]] = (int)$r["c"];
        $counts["All"] += (int)$r["c"];
    }
}

$sql = "SELECT id, name, email, verification_status, purok, address, id_file, verification_note, verification_submitted_at
        FROM users WHERE role = 'resident'";

if ($filter !== "All") {
    $stmt = $conn->prepare($sql . " AND verification_status = ? ORDER BY verification_submitted_at DESC, id DESC");
    $stmt->bind_param("s", $filter);
    $stmt->execute();
    $residents = $stmt->get_result();
} else {
    $residents = $conn->query($sql . " ORDER BY verification_submitted_at DESC, id DESC");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Resident Verification - Barangay Mabuhay</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="stylesheet" href="style.css?v=<?= @filemtime(__DIR__ . '/style.css') ?>">
</head>

<body>

<?php include "nav.php"; ?>

<div class="container">

    <h1 class="page-title">Resident Verification</h1>
    <p class="subtitle">Check that each resident really lives in Barangay Mabuhay before they can request documents.</p>

    <?php if ($flash !== ""): ?>
        <div class="message <?= $flash_type ?>"><?= htmlspecialchars($flash) ?></div>
    <?php endif; ?>

    <div class="tabs">
        <?php foreach ($filters as $key => $label): ?>
            <a class="tab-link<?= $key === $filter ? " on" : "" ?>" href="admin_residents.php?filter=<?= $key ?>">
                <?= $label ?> <span><?= (int)($counts[$key] ?? 0) ?></span>
            </a>
        <?php endforeach; ?>
    </div>

    <div class="toolbar">
        <div class="search-box">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
            <input type="search" placeholder="Search name, email, purok or address..." data-filter-table="resTable">
        </div>
    </div>

    <div class="table-box">
        <table id="resTable">
            <thead>
                <tr>
                    <th>Resident</th>
                    <th>Purok / Address</th>
                    <th>Submitted</th>
                    <th>Status</th>
                    <th>ID</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($residents && $residents->num_rows > 0): ?>
                <?php while ($r = $residents->fetch_assoc()): $st = $r["verification_status"] ?: "Unverified"; ?>
                <tr>
                    <td>
                        <strong><?= htmlspecialchars($r["name"]) ?></strong>
                        <span class="cell-sub"><?= htmlspecialchars($r["email"]) ?></span>
                    </td>
                    <td>
                        <?= htmlspecialchars($r["purok"] ?? "-") ?>
                        <span class="cell-sub"><?= htmlspecialchars($r["address"] ?? "") ?></span>
                    </td>
                    <td><?= $r["verification_submitted_at"] ? date("M d, Y", strtotime($r["verification_submitted_at"])) : "-" ?></td>
                    <td>
                        <span class="status status-<?= strtolower($st) ?>"><?= $st === "Unverified" ? "Not submitted" : htmlspecialchars($st) ?></span>
                        <?php if ($st === "Rejected" && !empty($r["verification_note"])): ?>
                            <span class="cell-sub"><?= htmlspecialchars($r["verification_note"]) ?></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if (!empty($r["id_file"])): ?>
                            <a class="id-link" href="view_id.php?id=<?= $r["id"] ?>" target="_blank">View ID</a>
                        <?php else: ?>-<?php endif; ?>
                    </td>
                    <td>
                        <?php if ($st !== "Unverified"): ?>
                        <div class="res-actions">
                            <?php if ($st !== "Verified"): ?>
                                <form method="POST">
                                    <input type="hidden" name="action" value="approve">
                                    <input type="hidden" name="user_id" value="<?= $r["id"] ?>">
                                    <input type="hidden" name="filter" value="<?= htmlspecialchars($filter) ?>">
                                    <button type="submit" class="btn-sm">Approve</button>
                                </form>
                            <?php endif; ?>
                            <?php if ($st !== "Rejected"): ?>
                                <details class="reject-box">
                                    <summary>Reject</summary>
                                    <form method="POST">
                                        <input type="hidden" name="action" value="reject">
                                        <input type="hidden" name="user_id" value="<?= $r["id"] ?>">
                                        <input type="hidden" name="filter" value="<?= htmlspecialchars($filter) ?>">
                                        <input type="text" name="note" placeholder="Reason (required)">
                                        <button type="submit" class="btn-sm btn-red">Confirm reject</button>
                                    </form>
                                </details>
                            <?php endif; ?>
                        </div>
                        <?php else: ?><span class="cell-sub">Waiting for resident</span><?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="6" style="text-align:center;color:var(--muted)">No residents in this list.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>

<script src="ui.js?v=<?= @filemtime(__DIR__ . '/ui.js') ?>"></script>
</body>
</html>
