<?php

require_once "config.php";
requireLogin();

if (isAdminRole($_SESSION["role"] ?? "")) {
    header("Location: admin_residents.php");
    exit();
}

ensureUserColumns($conn);

$user_id = $_SESSION["user_id"];

$stmt = $conn->prepare("SELECT name, email, verification_status, purok, address, verification_note FROM users WHERE id = ? LIMIT 1");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$me = $stmt->get_result()->fetch_assoc();
$stmt->close();

$status = $me["verification_status"] ?? "Unverified";
$errors = [];
$message = "";

$v = [
    "purok"   => $me["purok"] ?? "",
    "address" => $me["address"] ?? ""
];

if ($_SERVER["REQUEST_METHOD"] === "POST" && ($status === "Unverified" || $status === "Rejected")) {

    $v["purok"]   = trim($_POST["purok"] ?? "");
    $v["address"] = trim($_POST["address"] ?? "");

    if ($v["purok"] === "") { $errors["purok"] = "Purok / Zone is required."; }

    if ($v["address"] === "") {
        $errors["address"] = "Complete address is required.";
    } elseif (strlen($v["address"]) < 8) {
        $errors["address"] = "Please enter your full address (house no., street, barangay).";
    }

    if (!isset($_POST["confirm"])) { $errors["confirm"] = "Please confirm that you live in Barangay Mabuhay."; }

    $saved_name = "";
    $file = $_FILES["id_file"] ?? null;

    if (!$file || $file["error"] === UPLOAD_ERR_NO_FILE) {

        $errors["id_file"] = "Please upload a valid ID or proof of residency.";

    } elseif ($file["error"] !== UPLOAD_ERR_OK) {

        $errors["id_file"] = "The upload failed. Please try again.";

    } elseif ($file["size"] > 5 * 1024 * 1024) {

        $errors["id_file"] = "The file is too large (maximum 5 MB).";

    } else {

        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $allowed = ["image/jpeg" => "jpg", "image/png" => "png", "application/pdf" => "pdf"];
        $mime = $finfo->file($file["tmp_name"]);

        if (!isset($allowed[$mime])) {
            $errors["id_file"] = "Only JPG, PNG or PDF files are allowed.";
        } else {
            $saved_name = "id_" . $user_id . "_" . bin2hex(random_bytes(8)) . "." . $allowed[$mime];
        }
    }

    if (empty($errors)) {

        $dir = __DIR__ . "/uploads/ids/";

        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }

        if (!file_exists($dir . ".htaccess")) {
            @file_put_contents($dir . ".htaccess", "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder deny,allow\nDeny from all\n</IfModule>\n");
        }

        if (!move_uploaded_file($file["tmp_name"], $dir . $saved_name)) {

            $message = "We couldn't save your file. Please try again.";

        } else {

            $stmt = $conn->prepare("
                UPDATE users
                SET purok = ?, address = ?, id_file = ?, verification_status = 'Pending',
                    verification_note = NULL, verification_submitted_at = NOW()
                WHERE id = ?
            ");
            $stmt->bind_param("sssi", $v["purok"], $v["address"], $saved_name, $user_id);
            $stmt->execute();
            $stmt->close();

            header("Location: verify_residency.php?submitted=1");
            exit();
        }
    }
}

function bad($errors, $key) { return isset($errors[$key]) ? " invalid" : ""; }
function fieldError($errors, $key) {
    return isset($errors[$key]) ? '<div class="field-error">' . htmlspecialchars($errors[$key]) . '</div>' : '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Verify Residency - Barangay Mabuhay</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="stylesheet" href="style.css?v=<?= @filemtime(__DIR__ . '/style.css') ?>">
<script src="form.js?v=<?= @filemtime(__DIR__ . '/form.js') ?>" defer></script>
</head>

<body class="narrow">

<?php include "nav.php"; ?>

<div class="container">

    <h1>Verify Your Residency</h1>
    <p class="subtitle">To keep our records accurate, only people who live in Barangay Mabuhay, Bansalan can request documents.</p>

    <?php if (isset($_GET["need"]) && $status !== "Verified"): ?>
        <div class="error">Please verify that you live in the barangay before requesting a document.</div>
    <?php endif; ?>

    <?php if ($message !== ""): ?>
        <div class="error"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <?php if ($status === "Verified"): ?>

        <div class="state ok">
            <div>
                <strong>You are verified &#10003;</strong>
                <p>Your residency in Barangay Mabuhay has been confirmed. You can now request documents.</p>
            </div>
        </div>
        <a href="request.php" class="btn">Request a Document</a>

    <?php elseif ($status === "Pending"): ?>

        <div class="state pending">
            <div>
                <strong>Your verification is under review</strong>
                <p>The barangay office is checking your details. This page will show &ldquo;Verified&rdquo; once you are approved, and then you can request documents.</p>
            </div>
        </div>

        <div class="box">
            <div class="detail-grid">
                <div class="detail"><strong>Purok / Zone</strong><?= htmlspecialchars($me["purok"] ?? "") ?></div>
                <div class="detail"><strong>Address</strong><?= htmlspecialchars($me["address"] ?? "") ?></div>
            </div>
        </div>

    <?php else: ?>

        <?php if ($status === "Rejected"): ?>
            <div class="state bad">
                <div>
                    <strong>Your verification was not approved</strong>
                    <p><?= !empty($me["verification_note"]) ? "Reason: " . htmlspecialchars($me["verification_note"]) : "Please check your details and upload a clearer ID." ?> You can submit it again below.</p>
                </div>
            </div>
        <?php endif; ?>

        <div class="box">

            <form method="POST" enctype="multipart/form-data" novalidate data-validate>

                <label for="purok">Purok / Zone</label>
                <input type="text" id="purok" name="purok" class="<?= trim(bad($errors, 'purok')) ?>"
                       placeholder="e.g. Purok 3" data-label="Purok / Zone" required
                       value="<?= htmlspecialchars($v['purok']) ?>">
                <?= fieldError($errors, 'purok') ?>

                <label for="address">Complete Address</label>
                <input type="text" id="address" name="address" class="<?= trim(bad($errors, 'address')) ?>"
                       placeholder="House no., Street, Barangay Mabuhay, Bansalan" data-label="Address" required
                       value="<?= htmlspecialchars($v['address']) ?>">
                <?= fieldError($errors, 'address') ?>

                <label for="id_file">Valid ID or Proof of Residency</label>
                <input type="file" id="id_file" name="id_file" accept=".jpg,.jpeg,.png,.pdf" class="<?= trim(bad($errors, 'id_file')) ?>"
                       data-label="ID or proof" required>
                <div class="file-hint">Government ID, voter&rsquo;s ID, school ID, or a recent utility bill showing your address. JPG, PNG or PDF, up to 5 MB.</div>
                <?= fieldError($errors, 'id_file') ?>

                <label class="check">
                    <input type="checkbox" name="confirm" value="1">
                    <span>I confirm that I live in Barangay Mabuhay, Bansalan, and the details above are true.</span>
                </label>
                <?= fieldError($errors, 'confirm') ?>

                <button type="submit" style="width:100%;margin-top:22px;padding:15px">Submit for Verification</button>

            </form>

        </div>

    <?php endif; ?>

</div>

</body>
</html>
