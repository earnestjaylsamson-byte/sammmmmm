<?php

require_once "config.php";

$admin_name = "Barangay Admin";
$admin_email = "admin@civiclink.com";
$admin_password = "Admin12345";
$admin_role = "admin";

$check_admin = $conn->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");

if ($check_admin) {

    $check_admin->bind_param("s", $admin_email);
    $check_admin->execute();

    $admin_result = $check_admin->get_result();

    if ($admin_result->num_rows === 0) {

        $hashed_admin_password = password_hash(
            $admin_password,
            PASSWORD_DEFAULT
        );

        $create_admin = $conn->prepare("
            INSERT INTO users (name, email, password, role)
            VALUES (?, ?, ?, ?)
        ");

        if ($create_admin) {

            $create_admin->bind_param(
                "ssss",
                $admin_name,
                $admin_email,
                $hashed_admin_password,
                $admin_role
            );

            $create_admin->execute();
            $create_admin->close();
        }

    }

    $check_admin->close();
}

$error = "";
$errors = [];
$email = "";
$password = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";

    if ($email === "" || $password === "") {

        if ($email === "") { $errors["email"] = "Please enter your email."; }
        if ($password === "") { $errors["password"] = "Please enter your password."; }

    } else {

        $stmt = $conn->prepare("
            SELECT id, name, email, password, role
            FROM users
            WHERE email = ?
            LIMIT 1
        ");

        if (!$stmt) {

            $error = "Database error: " . $conn->error;

        } else {

            $stmt->bind_param("s", $email);
            $stmt->execute();

            $result = $stmt->get_result();

            if ($result->num_rows === 1) {

                $user = $result->fetch_assoc();

                if (password_verify($password, $user["password"])) {

                    session_regenerate_id(true);

                    $_SESSION["user_id"] = $user["id"];
                    $_SESSION["user_name"] = $user["name"];
                    $_SESSION["user_email"] = $user["email"];
                    $_SESSION["role"] = $user["role"];

                    if (in_array($user["role"], [
                        "admin",
                        "barangay_admin",
                        "staff",
                        "secretary",
                        "system_admin"
                    ])) {

                        header("Location: admin.php");
                        exit();

                    }

                    header("Location: dashboard.php");
                    exit();

                } else {

                    $errors["password"] = "Incorrect password.";

                }

            } else {

                $errors["email"] = "No account found with this email.";

            }

            $stmt->close();
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Barangay Mabuhay - Login</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="stylesheet" href="style.css?v=<?= @filemtime(__DIR__ . '/style.css') ?>">
<script src="form.js?v=<?= @filemtime(__DIR__ . '/form.js') ?>" defer></script>
</head>

<body class="auth">

<?php include "nav.php"; ?>

<div class="container">

    <div class="card">

        <img class="auth-logo" src="logo.png" alt="Barangay Mabuhay logo">
        <h1>Welcome Back</h1>

        <p class="subtitle">
            Login to your Barangay Mabuhay account
        </p>

        <?php if ($error !== ""): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if (isset($_GET["registered"])): ?>
            <div class="message">Account created! You can now log in.</div>
        <?php endif; ?>

        <form method="POST" action="login.php" novalidate data-validate>

            <label for="email">Email</label>
            <input type="email" id="email" name="email" placeholder="Enter your email"
                   data-rule="email" data-label="Email" required
                   class="<?= isset($errors['email']) ? 'invalid' : '' ?>"
                   value="<?= htmlspecialchars($email) ?>">
            <?php if (isset($errors["email"])): ?><div class="field-error"><?= htmlspecialchars($errors["email"]) ?></div><?php endif; ?>

            <label for="password">Password</label>
            <input type="password" id="password" name="password" placeholder="Enter your password"
                   data-label="Password" required
                   class="<?= isset($errors['password']) ? 'invalid' : '' ?>"
                   value="<?= isset($errors['password']) ? '' : htmlspecialchars($password) ?>">
            <?php if (isset($errors["password"])): ?><div class="field-error"><?= htmlspecialchars($errors["password"]) ?></div><?php endif; ?>

            <button type="submit">
                Login
            </button>

        </form>

        <div class="register">

            Don't have an account?

            <a href="register.php">
                Register
            </a>

        </div>

    </div>

</div>

</body>

</html>