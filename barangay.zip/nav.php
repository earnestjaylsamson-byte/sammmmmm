<?php
/*
 * Left sidebar navigation. Changes with who is viewing:
 *   Visitor  : Home, Login, Register
 *   Resident : Dashboard, Request Document, My Requests, Verify Residency, Logout
 *   Admin    : Dashboard, Requests, Residents, Logout
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!function_exists("navIcon")) {
    function navIcon($name) {
        $paths = [
            "home"   => '<path d="m3 11 9-8 9 8"/><path d="M5 10v10h14V10"/>',
            "grid"   => '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
            "filep"  => '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M12 12v6M9 15h6"/>',
            "list"   => '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
            "shield" => '<path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6z"/><path d="m9 12 2 2 4-4"/>',
            "users"  => '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M18 14c2.2.6 3.5 2.4 3.5 5"/>',
            "login"  => '<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4M10 17l5-5-5-5M15 12H3"/>',
            "userp"  => '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6M19 8v6M16 11h6"/>',
            "logout" => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
            "menu"   => '<path d="M4 6h16M4 12h16M4 18h16"/>'
        ];
        return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ($paths[$name] ?? "") . '</svg>';
    }
}

$logged_in = isset($_SESSION["user_id"]);
$is_admin  = $logged_in && in_array($_SESSION["role"] ?? "", ["admin", "barangay_admin", "staff", "secretary", "system_admin"], true);

// [file, label, icon, badge text, badge class]
$items = [];
$home  = "index.php";

if ($is_admin) {

    $home = "admin.php";
    $pending_residents = 0;

    if (isset($conn)) {
        try {
            $r = $conn->query("SELECT COUNT(*) AS c FROM users WHERE role = 'resident' AND verification_status = 'Pending'");
            if ($r) { $pending_residents = (int)$r->fetch_assoc()["c"]; }
        } catch (Throwable $e) { $pending_residents = 0; }
    }

    $items = [
        ["admin.php",           "Dashboard", "grid",  "", ""],
        ["admin_requests.php",  "Requests",  "list",  "", ""],
        ["admin_residents.php", "Residents", "users", $pending_residents > 0 ? (string)$pending_residents : "", ""]
    ];

} elseif ($logged_in) {

    $home = "dashboard.php";
    $vs = isset($conn) ? getVerificationStatus($conn, $_SESSION["user_id"]) : "";

    $badge = ["", ""];
    if ($vs === "Verified")      { $badge = ["Verified", "ok"]; }
    elseif ($vs === "Pending")   { $badge = ["Pending", ""]; }
    elseif ($vs === "Rejected")  { $badge = ["Redo", "bad"]; }
    elseif ($vs !== "")          { $badge = ["Needed", ""]; }

    $items = [
        ["dashboard.php",        "Dashboard",         "grid",   "", ""],
        ["request.php",          "Request Document",  "filep",  "", ""],
        ["my_requests.php",      "My Requests",       "list",   "", ""],
        ["verify_residency.php", "Verify Residency",  "shield", $badge[0], $badge[1]]
    ];

} else {

    $items = [
        ["index.php",    "Home",     "home",  "", ""],
        ["login.php",    "Login",    "login", "", ""],
        ["register.php", "Register", "userp", "", ""]
    ];
}

$current = basename($_SERVER["PHP_SELF"]);
$parents = [
    "admin_request.php" => "admin_requests.php",
    "view_request.php"  => "my_requests.php",
    "payment.php"       => "my_requests.php",
    "verify_email.php"  => "register.php"
];
if (isset($parents[$current])) { $current = $parents[$current]; }

$user_name = $_SESSION["user_name"] ?? "";
$initial   = $user_name !== "" ? strtoupper(substr($user_name, 0, 1)) : "?";
?>
<?php if (!$logged_in): ?>
<header class="topnav">
    <div class="topnav-inner">
        <a href="index.php" class="brand">
            <img src="logo.png" alt="Barangay Mabuhay logo">
            <span>Barangay Mabuhay</span>
        </a>
        <nav class="topnav-links">
            <?php foreach ($items as $item): ?>
                <a href="<?= $item[0] ?>" class="<?= $item[0] === $current ? "active" : "" ?><?= $item[0] === "register.php" ? " cta" : "" ?>"><?= $item[1] ?></a>
            <?php endforeach; ?>
        </nav>
    </div>
</header>
<?php return; endif; ?>
<script>document.body.classList.add("has-sidebar");</script>
<div class="topbar">
    <button type="button" class="menu-btn" id="menuBtn" aria-label="Open menu"><?= navIcon("menu") ?></button>
    <img src="logo.png" alt="">
    <strong>Barangay Mabuhay</strong>
</div>

<div class="side-overlay" id="sideOverlay"></div>

<aside class="sidebar" id="sidebar">

    <a href="<?= $home ?>" class="side-brand">
        <img src="logo.png" alt="Barangay Mabuhay logo">
        <span>
            <strong>Barangay Mabuhay</strong>
            <small>Bansalan &middot; Information System</small>
        </span>
    </a>

    <div class="side-label">Menu</div>

    <nav class="side-nav">
        <?php foreach ($items as $item): ?>
            <a href="<?= $item[0] ?>"<?= $item[0] === $current ? ' class="active"' : '' ?>>
                <?= navIcon($item[2]) ?>
                <span><?= $item[1] ?></span>
                <?php if ($item[3] !== ""): ?>
                    <em class="side-badge <?= $item[4] ?>"><?= htmlspecialchars($item[3]) ?></em>
                <?php endif; ?>
            </a>
        <?php endforeach; ?>
    </nav>

    <?php if ($logged_in): ?>
        <div class="side-user">
            <div class="side-avatar"><?= htmlspecialchars($initial) ?></div>
            <div>
                <strong><?= htmlspecialchars($user_name) ?></strong>
                <small><?= $is_admin ? "Administrator" : "Resident" ?></small>
            </div>
        </div>
        <a href="logout.php" class="side-logout"><?= navIcon("logout") ?><span>Logout</span></a>
    <?php endif; ?>

</aside>

<script>
(function () {
    var body = document.body;
    function toggle(open) { body.classList.toggle("menu-open", open); }
    document.getElementById("menuBtn").addEventListener("click", function () { toggle(!body.classList.contains("menu-open")); });
    document.getElementById("sideOverlay").addEventListener("click", function () { toggle(false); });
    document.querySelectorAll(".side-nav a").forEach(function (a) { a.addEventListener("click", function () { toggle(false); }); });
})();
</script>
