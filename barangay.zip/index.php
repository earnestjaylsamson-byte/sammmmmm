<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barangay Mabuhay - Barangay Information System</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="stylesheet" href="style.css?v=<?= @filemtime(__DIR__ . '/style.css') ?>">
</head>

<body>

<?php include "nav.php"; ?>

<section class="hero">
    <div class="hero-content">
        <img src="logo.png" alt="Sangguniang Kabataan - Barangay Mabuhay, Bansalan" class="hero-logo">
        <h1>Barangay Mabuhay</h1>

        <h2>Barangay Information and Document Request System</h2>

        <p>
            This system provides a simple and convenient way for residents
            to manage their barangay information and request important
            documents online.
        </p>

        <div class="buttons">
            <a href="login.php" class="btn btn-primary">Login</a>
            <a href="register.php" class="btn btn-secondary">Create Account</a>
        </div>
    </div>
</section>

<section class="features">
    <h2>What Barangay Mabuhay Offers</h2>

    <div class="feature-container">

        <div class="feature-card">
            <h3>Resident Information</h3>
            <p>
                Manage and maintain resident information in an organized
                digital system.
            </p>
        </div>

        <div class="feature-card">
            <h3>Document Requests</h3>
            <p>
                Request barangay documents online and monitor the status
                of your requests.
            </p>
        </div>

        <div class="feature-card">
            <h3>Easy Access</h3>
            <p>
                Access your account and barangay services through a simple
                and convenient online system.
            </p>
        </div>

    </div>
</section>

<footer>
    <p>© 2026 Barangay Mabuhay. Barangay Information System.</p>
</footer>

</body>
</html>