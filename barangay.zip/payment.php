<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "config.php";
requireLogin();


$id = isset($_GET["id"]) ? intval($_GET["id"]) : 0;

$stmt = $conn->prepare("
    SELECT *
    FROM document_requests
    WHERE id = ?
    AND user_id = ?
    LIMIT 1
");

$stmt->bind_param(
    "ii",
    $id,
    $_SESSION["user_id"]
);

$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    die("Request not found.");
}

$request = $result->fetch_assoc();

if (
    $request["status"] !== "Payment Required" ||
    floatval($request["amount"]) <= 0
) {
    header("Location: view_request.php?id=" . $request["id"]);
    exit();
}

$check_payment = $conn->prepare("
    SELECT *
    FROM payments
    WHERE request_id = ?
    AND user_id = ?
    ORDER BY id DESC
    LIMIT 1
");

$check_payment->bind_param(
    "ii",
    $request["id"],
    $_SESSION["user_id"]
);

$check_payment->execute();

$payment_result = $check_payment->get_result();

if ($payment_result->num_rows === 1) {

    $existing_payment = $payment_result->fetch_assoc();

    if ($existing_payment["status"] !== "Rejected") {
        header("Location: view_request.php?id=" . $request["id"]);
        exit();
    }
}

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $payment_method = trim($_POST["payment_method"] ?? "");

    if (
        $payment_method !== "GCash" &&
        $payment_method !== "COD"
    ) {
        $error = "Please choose a valid payment method.";
    } else {

        $check_active = $conn->prepare("
            SELECT id
            FROM payments
            WHERE request_id = ?
            AND user_id = ?
            AND status <> 'Rejected'
            LIMIT 1
        ");

        $check_active->bind_param(
            "ii",
            $request["id"],
            $_SESSION["user_id"]
        );

        $check_active->execute();

        $active_result = $check_active->get_result();

        if ($active_result->num_rows > 0) {

            header(
                "Location: view_request.php?id=" .
                $request["id"]
            );

            exit();
        }

        $check_active->close();


        if ($payment_method === "GCash") {

            $reference_number = trim(
                $_POST["reference_number"] ?? ""
            );

            $delivery_method = trim($_POST["delivery_method"] ?? "");
            $delivery_address = trim($_POST["delivery_address"] ?? "");
            $delivery_error = "";

            if (
                $delivery_method !== "Pickup" &&
                $delivery_method !== "Delivery"
            ) {
                $delivery_error = "Please choose Pickup or Delivery.";
            } elseif (
                $delivery_method === "Delivery" &&
                $delivery_address === ""
            ) {
                $delivery_error = "Please enter your delivery address.";
            } elseif ($delivery_method === "Pickup") {
                $delivery_address = null;
            }

            if ($reference_number === "") {

                $error = "Please enter your GCash reference number.";

            } elseif ($delivery_error !== "") {

                $error = $delivery_error;

            } elseif (
                !isset($_FILES["proof_file"]) ||
                $_FILES["proof_file"]["error"] !== UPLOAD_ERR_OK
            ) {

                $error = "Please upload your GCash payment screenshot.";

            } else {

                $file = $_FILES["proof_file"];

                $max_size = 5 * 1024 * 1024;

                if ($file["size"] > $max_size) {

                    $error = "The screenshot must not exceed 5 MB.";

                } else {

                    $finfo = new finfo(FILEINFO_MIME_TYPE);

                    $mime_type = $finfo->file(
                        $file["tmp_name"]
                    );

                    $allowed_types = [
                        "image/jpeg" => "jpg",
                        "image/png" => "png",
                        "image/webp" => "webp"
                    ];

                    if (
                        !isset(
                            $allowed_types[$mime_type]
                        )
                    ) {

                        $error = "Please upload a valid JPG, PNG, or WEBP image.";

                    } else {

                        $upload_directory =
                            __DIR__ . "/uploads/proofs/";

                        if (
                            !is_dir($upload_directory)
                        ) {
                            mkdir(
                                $upload_directory,
                                0755,
                                true
                            );
                        }

                        $extension =
                            $allowed_types[$mime_type];

                        $filename =
                            "gcash_" .
                            $request["id"] .
                            "_" .
                            time() .
                            "_" .
                            bin2hex(
                                random_bytes(4)
                            ) .
                            "." .
                            $extension;

                        $destination =
                            $upload_directory .
                            $filename;

                        if (
                            !move_uploaded_file(
                                $file["tmp_name"],
                                $destination
                            )
                        ) {

                            $error =
                                "Unable to upload the payment screenshot.";

                        } else {

                            $insert_payment = $conn->prepare("
                                INSERT INTO payments
                                (
                                    request_id,
                                    user_id,
                                    amount,
                                    payment_method,
                                    delivery_method,
                                    delivery_address,
                                    reference_number,
                                    proof_file,
                                    status
                                )
                                VALUES
                                (
                                    ?,
                                    ?,
                                    ?,
                                    ?,
                                    ?,
                                    ?,
                                    ?,
                                    ?,
                                    'Pending Verification'
                                )
                            ");

                            if (!$insert_payment) {

                                $error =
                                    "Unable to prepare the payment.";

                            } else {

                                $amount =
                                    floatval(
                                        $request["amount"]
                                    );

                                $insert_payment->bind_param(
                                    "iidsssss",
                                    $request["id"],
                                    $_SESSION["user_id"],
                                    $amount,
                                    $payment_method,
                                    $delivery_method,
                                    $delivery_address,
                                    $reference_number,
                                    $filename
                                );

                                if (
                                    $insert_payment->execute()
                                ) {

                                    $payment_status =
                                        "Payment Processing";

                                    $update_request =
                                        $conn->prepare("
                                            UPDATE document_requests
                                            SET
                                                payment_status = ?,
                                                payment_reference = ?
                                            WHERE id = ?
                                            AND user_id = ?
                                        ");

                                    $update_request->bind_param(
                                        "ssii",
                                        $payment_status,
                                        $reference_number,
                                        $request["id"],
                                        $_SESSION["user_id"]
                                    );

                                    $update_request->execute();
                                    $update_request->close();

                                    header(
                                        "Location: view_request.php?id=" .
                                        $request["id"]
                                    );

                                    exit();

                                } else {

                                    $error =
                                        "Unable to submit the GCash payment.";

                                    if (
                                        file_exists(
                                            $destination
                                        )
                                    ) {
                                        unlink(
                                            $destination
                                        );
                                    }
                                }

                                $insert_payment->close();
                            }
                        }
                    }
                }
            }


        } elseif ($payment_method === "COD") {

            $delivery_method =
                trim(
                    $_POST["delivery_method"] ?? ""
                );

            $delivery_address =
                trim(
                    $_POST["delivery_address"] ?? ""
                );

            if (
                $delivery_method !== "Pickup" &&
                $delivery_method !== "Delivery"
            ) {

                $error =
                    "Please choose Pickup or Delivery.";

            } elseif (
                $delivery_method === "Delivery" &&
                $delivery_address === ""
            ) {

                $error =
                    "Please enter your delivery address.";

            } else {

                if (
                    $delivery_method === "Pickup"
                ) {
                    $delivery_address = null;
                }

                $amount =
                    floatval(
                        $request["amount"]
                    );

                $reference_number =
                    "COD-" .
                    $request["id"] .
                    "-" .
                    date("YmdHis");

                $insert_payment = $conn->prepare("
                    INSERT INTO payments
                    (
                        request_id,
                        user_id,
                        amount,
                        payment_method,
                        delivery_method,
                        delivery_address,
                        reference_number,
                        proof_file,
                        status
                    )
                    VALUES
                    (
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        NULL,
                        'COD Pending'
                    )
                ");

                if (!$insert_payment) {

                    $error =
                        "Unable to prepare the COD payment.";

                } else {

                    $insert_payment->bind_param(
                        "iidssss",
                        $request["id"],
                        $_SESSION["user_id"],
                        $amount,
                        $payment_method,
                        $delivery_method,
                        $delivery_address,
                        $reference_number
                    );

                    if (
                        $insert_payment->execute()
                    ) {

                        $payment_status =
                            "COD Pending";

                        $update_request =
                            $conn->prepare("
                                UPDATE document_requests
                                SET
                                    payment_status = ?,
                                    payment_reference = ?
                                WHERE id = ?
                                AND user_id = ?
                            ");

                        $update_request->bind_param(
                            "ssii",
                            $payment_status,
                            $reference_number,
                            $request["id"],
                            $_SESSION["user_id"]
                        );

                        $update_request->execute();
                        $update_request->close();

                        header(
                            "Location: view_request.php?id=" .
                            $request["id"]
                        );

                        exit();

                    } else {

                        $error =
                            "Unable to submit the COD payment.";
                    }

                    $insert_payment->close();
                }
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Payment - Barangay Mabuhay</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="stylesheet" href="style.css?v=<?= @filemtime(__DIR__ . '/style.css') ?>">
</head>

<body class="narrow">

<?php include "nav.php"; ?>

<div class="container">

    <div class="box">

        <h1>Choose Payment Method</h1>

        <p class="subtitle">
            Select how you want to pay for your document request.
            You can change your choice before submitting the payment.
        </p>

        <div class="request-info">

            <p>
                <strong>Request Number:</strong>
                <?php echo htmlspecialchars(
                    $request["request_number"]
                ); ?>
            </p>

            <p>
                <strong>Document:</strong>
                <?php echo htmlspecialchars(
                    $request["document_type"]
                ); ?>
            </p>

            <p>
                <strong>Amount:</strong>
                <span class="amount">
                    ₱<?php echo number_format(
                        $request["amount"],
                        2
                    ); ?>
                </span>
            </p>

        </div>

        <?php if ($error !== ""): ?>

            <div class="error">
                <?php echo htmlspecialchars($error); ?>
            </div>

        <?php endif; ?>


        <div class="payment-options">

            <button
                type="button"
                class="payment-option"
                id="gcash-option"
                onclick="selectPayment('GCash')"
            >

                <strong>
                    GCash
                </strong>

                <span>
                    Pay using GCash
                </span>

            </button>


            <button
                type="button"
                class="payment-option"
                id="cod-option"
                onclick="selectPayment('COD')"
            >

                <strong>
                    Cash on Delivery
                </strong>

                <span>
                    Pay when receiving your document
                </span>

            </button>

        </div>


        <form
            method="POST"
            enctype="multipart/form-data"
            id="payment-form"
        >

            <input
                type="hidden"
                name="payment_method"
                id="payment_method"
                value=""
            >


            <div
                class="payment-section"
                id="gcash-section"
            >

                <h2 class="section-title">
                    GCash Payment
                </h2>

                <div class="gcash-info">

                    <p>
                        <strong>GCash Number:</strong>
                        09362275809
                    </p>

                    <p>
                        <strong>Account Name:</strong>
                        Barangay Information Request System
                    </p>

                </div>


                <p class="instructions">

                    Send the required payment using GCash.
                    After payment, upload your GCash screenshot
                    and enter the reference number.

                </p>


                <div class="qr-container">

                    <?php if (
                        file_exists(
                            __DIR__ .
                            "/uploads/gcash_qr.png"
                        )
                    ): ?>

                        <img
                            src="uploads/gcash_qr.png"
                            alt="GCash QR Code"
                        >

                    <?php endif; ?>

                </div>


                <div class="scan-box">

                    <p>
                        Upload a clear screenshot of your GCash payment.
                        The system will check whether the uploaded file
                        is a readable image containing payment-related
                        information.
                    </p>

                    <p>
                        For testing, the scanner does not require an
                        exact payment amount or exact account name.
                        Final verification is still done by the administrator.
                    </p>

                    <div
                        class="scan-status"
                        id="scan-status"
                    ></div>

                </div>


                <label for="proof_file">
                    GCash Payment Screenshot
                </label>

                <input
                    type="file"
                    name="proof_file"
                    id="proof_file"
                    accept="image/jpeg,image/png,image/webp"
                >


                <label for="reference_number">
                    GCash Reference Number
                </label>

                <input
                    type="text"
                    name="reference_number"
                    id="reference_number"
                    placeholder="Enter GCash reference number"
                >


                <button
                    type="button"
                    class="submit-button"
                    id="scan-button"
                    onclick="scanScreenshot()"
                >
                    Scan Screenshot
                </button>


                <div class="test-mode">

                    Testing mode: the screenshot scanner does not require
                    the amount or account name to exactly match the request.
                    The uploaded payment will still be marked
                    <strong>Pending Verification</strong> until an
                    administrator verifies it.

                </div>

            </div>


            <div
                class="payment-section"
                id="cod-section"
            >

                <h2 class="section-title">
                    Cash on Delivery
                </h2>

                <p class="instructions">

                    Pay in cash when you receive or pick up your document.
                    Choose Pickup or Delivery below.

                </p>
            </div>


            <div
                class="payment-section"
                id="delivery-section"
            >

                <h2 class="section-title">
                    Pickup or Delivery
                </h2>

                <p class="instructions">
                    Choose how you want to receive your document.
                </p>

                <label for="delivery_method">
                    Delivery Method
                </label>

                <select
                    name="delivery_method"
                    id="delivery_method"
                    onchange="changeDeliveryMethod()"
                >

                    <option value="">
                        Choose an option
                    </option>

                    <option value="Pickup">
                        Pickup
                    </option>

                    <option value="Delivery">
                        Delivery
                    </option>

                </select>


                <div
                    class="delivery-box"
                    id="delivery-box"
                >

                    <label for="delivery_address">
                        Delivery Address
                    </label>

                    <textarea
                        name="delivery_address"
                        id="delivery_address"
                        placeholder="Enter your complete delivery address"
                    ></textarea>

                </div>

            </div>


            <button
                type="submit"
                class="submit-button"
                id="submit-button"
                style="display:none;"
            >
                Submit Payment
            </button>

        </form>


        <a
            href="view_request.php?id=<?php echo $request["id"]; ?>"
            class="back-btn"
        >
            Back to Request
        </a>

    </div>

</div>


<script>

let selectedPayment = "";

let gcashScanned = false;


function selectPayment(method) {

    selectedPayment = method;

    document.getElementById(
        "payment_method"
    ).value = method;

    document.getElementById(
        "gcash-option"
    ).classList.remove("active");

    document.getElementById(
        "cod-option"
    ).classList.remove("active");

    document.getElementById(
        "gcash-section"
    ).classList.remove("active");

    document.getElementById(
        "cod-section"
    ).classList.remove("active");

    document.getElementById(
        "delivery-section"
    ).classList.remove("active");


    if (method === "GCash") {

        document.getElementById(
            "gcash-option"
        ).classList.add("active");

        document.getElementById(
            "gcash-section"
        ).classList.add("active");

        document.getElementById(
            "submit-button"
        ).style.display = "none";

    }


    if (method === "COD") {

        document.getElementById(
            "cod-option"
        ).classList.add("active");

        document.getElementById(
            "cod-section"
        ).classList.add("active");

        document.getElementById(
            "submit-button"
        ).style.display = "block";

    }

    document.getElementById(
        "delivery-section"
    ).classList.add("active");

}


function changeDeliveryMethod() {

    const method =
        document.getElementById(
            "delivery_method"
        ).value;

    const deliveryBox =
        document.getElementById(
            "delivery-box"
        );

    if (method === "Delivery") {

        deliveryBox.classList.add("active");

    } else {

        deliveryBox.classList.remove("active");

        document.getElementById(
            "delivery_address"
        ).value = "";

    }

}


async function scanScreenshot() {

    const fileInput =
        document.getElementById(
            "proof_file"
        );

    const scanStatus =
        document.getElementById(
            "scan-status"
        );

    const submitButton =
        document.getElementById(
            "submit-button"
        );

    if (!fileInput.files.length) {

        scanStatus.className =
            "scan-status warning";

        scanStatus.innerHTML =
            "Please upload your GCash screenshot first.";

        return;
    }


    const file =
        fileInput.files[0];


    if (
        file.type !== "image/jpeg" &&
        file.type !== "image/png" &&
        file.type !== "image/webp"
    ) {

        scanStatus.className =
            "scan-status warning";

        scanStatus.innerHTML =
            "Please upload a JPG, PNG, or WEBP image.";

        return;
    }


    if (file.size > 5 * 1024 * 1024) {

        scanStatus.className =
            "scan-status warning";

        scanStatus.innerHTML =
            "The screenshot must not exceed 5 MB.";

        return;
    }


    scanStatus.className =
        "scan-status warning";

    scanStatus.innerHTML =
        "Checking screenshot...";


    try {

        const image =
            new Image();

        image.onload = async function() {

            const canvas =
                document.createElement(
                    "canvas"
                );

            const scale = 2;

            canvas.width =
                image.width * scale;

            canvas.height =
                image.height * scale;

            const context =
                canvas.getContext(
                    "2d"
                );

            context.drawImage(
                image,
                0,
                0,
                canvas.width,
                canvas.height
            );


            let recognizedText = "";


            if (
                typeof Tesseract !==
                "undefined"
            ) {

                const result =
                    await Tesseract.recognize(
                        canvas,
                        "eng"
                    );

                recognizedText =
                    result.data.text
                    .toLowerCase();

            }


            const paymentWords = [
                "gcash",
                "payment",
                "paid",
                "sent",
                "successful",
                "transaction",
                "reference",
                "amount",
                "php",
                "₱"
            ];


            let matchedWords = 0;


            paymentWords.forEach(
                function(word) {

                    if (
                        recognizedText.includes(
                            word
                        )
                    ) {

                        matchedWords++;

                    }

                }
            );


            gcashScanned = true;


            if (matchedWords >= 1) {

                scanStatus.className =
                    "scan-status success";

                scanStatus.innerHTML =
                    "Screenshot accepted for testing. Amount and account name do not need to exactly match.";

            } else {

                scanStatus.className =
                    "scan-status warning";

                scanStatus.innerHTML =
                    "The image was uploaded successfully, but the scanner could not recognize enough payment text. You may still submit it for administrator verification.";

            }


            submitButton.style.display =
                "block";

        };


        image.onerror =
            function() {

                scanStatus.className =
                    "scan-status warning";

                scanStatus.innerHTML =
                    "Unable to read the screenshot.";

            };


        image.src =
            URL.createObjectURL(file);

    } catch (error) {

        gcashScanned = true;

        scanStatus.className =
            "scan-status warning";

        scanStatus.innerHTML =
            "Screenshot uploaded. It will be checked by the administrator.";

        submitButton.style.display =
            "block";
    }

}


document.getElementById(
    "payment-form"
).addEventListener(
    "submit",
    function(event) {

        if (
            selectedPayment === ""
        ) {

            event.preventDefault();

            alert(
                "Please choose a payment method."
            );

            return;
        }


        if (
            selectedPayment === "GCash"
        ) {

            const fileInput =
                document.getElementById(
                    "proof_file"
                );

            const reference =
                document.getElementById(
                    "reference_number"
                ).value.trim();


            if (
                !fileInput.files.length
            ) {

                event.preventDefault();

                alert(
                    "Please upload your GCash payment screenshot."
                );

                return;
            }


            if (
                reference === ""
            ) {

                event.preventDefault();

                alert(
                    "Please enter your GCash reference number."
                );

                return;
            }

        }


        if (
            selectedPayment === "COD" ||
            selectedPayment === "GCash"
        ) {

            const deliveryMethod =
                document.getElementById(
                    "delivery_method"
                ).value;


            if (
                deliveryMethod !== "Pickup" &&
                deliveryMethod !== "Delivery"
            ) {

                event.preventDefault();

                alert(
                    "Please choose Pickup or Delivery."
                );

                return;
            }


            if (
                deliveryMethod === "Delivery"
            ) {

                const address =
                    document.getElementById(
                        "delivery_address"
                    ).value.trim();


                if (address === "") {

                    event.preventDefault();

                    alert(
                        "Please enter your delivery address."
                    );

                    return;
                }

            }

        }

    }
);

</script>


<script src="https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js"></script>

</body>

</html>