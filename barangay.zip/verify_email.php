<?php

require_once "config.php";
require_once "mailer.php";

if (isset($_SESSION["user_id"])) {
    header("Location: " . (in_array($_SESSION["role"] ?? "", ADMIN_ROLES, true) ? "admin.php" : "dashboard.php"));
    exit();
}

if (isset($_GET["cancel"]) || !isset($_SESSION["pending_register"])) {
    unset($_SESSION["pending_register"]);
    header("Location: register.php");
    exit();
}

$pending = $_SESSION["pending_register"];
$error = "";
$notice = "";
$code_error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $action = $_POST["action"] ?? "verify";

    if ($action === "resend") {

        $wait = OTP_RESEND_SECONDS - (time() - $pending["sent_at"]);

        if ($wait > 0) {

            $error = "Please wait " . $wait . " seconds before requesting a new code.";

        } elseif (startRegistrationVerification($pending["name"], $pending["email"], $pending["password_hash"], $mail_error)) {

            $pending = $_SESSION["pending_register"];
            $notice = "A new code was sent to " . maskEmail($pending["sent_to"]) . ".";

        } else {

            $error = "We couldn't send a new code." . (SMTP_DEBUG ? " (" . $mail_error . ")" : "");
        }

    } else {

        $entered = preg_replace("/\D/", "", $_POST["code"] ?? "");

        if (strlen($entered) !== 6) {

            $code_error = "Enter the 6-digit code.";

        } elseif (time() > $pending["expires"]) {

            $code_error = "This code has expired. Please request a new one.";

        } elseif ($pending["attempts"] >= OTP_MAX_ATTEMPTS) {

            $code_error = "Too many wrong attempts. Please request a new code.";

        } elseif (password_verify($entered, $pending["code_hash"])) {

            $created = createResident($conn, $pending["name"], $pending["email"], $pending["password_hash"], $create_error);
            unset($_SESSION["pending_register"]);

            if ($created) {
                header("Location: login.php?registered=1");
                exit();
            }

            $error = $create_error;
            $code_error = "";

        } else {

            $_SESSION["pending_register"]["attempts"]++;
            $left = OTP_MAX_ATTEMPTS - $_SESSION["pending_register"]["attempts"];
            $code_error = $left > 0
                ? "Incorrect code. " . $left . " attempt" . ($left === 1 ? "" : "s") . " left."
                : "Too many wrong attempts. Please request a new code.";
        }
    }
}

$resend_wait = max(0, OTP_RESEND_SECONDS - (time() - $pending["sent_at"]));
?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Barangay Mabuhay - Login</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="stylesheet" href="style.css?v=<?= @filemtime(__DIR__ . '/style.css') ?>">
<script src="form.js?v=<?= @filemtime(__DIR__ . '/form.js') ?>" defer></script>
</head>

<body>

<?php include "nav.php"; ?>

<?php
// Mask the email for display, e.g. j••••@gmail.com
$at = strpos($pending["sent_to"], "@");
$masked_email = substr($pending["sent_to"], 0, 1) . "••••" . ($at !== false ? substr($pending["sent_to"], $at) : "");
?>

<div class="verify-wrap">

    <div class="verify-hero">
        <div class="eyebrow">One last step</div>
        <h1>Verify your Gmail.</h1>
        <?php if (!empty($pending["demo_code"])): ?>
            <p>Email sending is not set up yet, so your code is shown below. Enter it to finish creating your account.</p>
        <?php else: ?>
            <p>
                We sent a 6-digit code to <strong><?= htmlspecialchars($masked_email) ?></strong>.
                This confirms that the email really belongs to you.
            </p>
        <?php endif; ?>
    </div>

    <div class="verify-card">

        <h2>Enter verification code</h2>
        <p>Type the 6-digit code from the email we sent to <?= htmlspecialchars($masked_email) ?>.</p>

        <?php if (!empty($pending["demo_code"])): ?>
            <div class="demo-box">
                <span class="demo-label">Demo mode &mdash; no email was sent</span>
                <span>Your verification code is</span>
                <div class="demo-code"><?= htmlspecialchars($pending["demo_code"]) ?></div>
                <?php if (SMTP_DEBUG && !empty($pending["mail_error"])): ?>
                    <small><b>Why no email was sent:</b> <?= htmlspecialchars($pending["mail_error"]) ?></small>
                <?php endif; ?>
                <small>To send real codes to Gmail, fix the Gmail details in mail_config.php.</small>
            </div>
        <?php endif; ?>

        <div class="tip-box">
            <div class="tip-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="m3 8 9 6 9-6"/></svg>
            </div>
            <div>
                <strong>Can&rsquo;t find your verification email?</strong>
                <p>Check your Gmail <b>Inbox, Spam, or Promotions</b> folder. The code expires after <?= OTP_EXPIRY_MINUTES ?> minutes; you can request another after <?= OTP_RESEND_SECONDS ?> seconds.</p>
            </div>
        </div>

        <?php if ($error !== ""): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if ($notice !== ""): ?>
            <div class="message"><?= htmlspecialchars($notice) ?></div>
        <?php endif; ?>

        <form method="POST" action="verify_email.php" id="verifyForm" novalidate>
            <input type="hidden" name="action" value="verify">
            <input type="hidden" name="code" id="code" value="">

            <div class="otp-boxes">
                <?php for ($i = 0; $i < 6; $i++): ?>
                    <input type="text" class="otp-box<?= $code_error !== "" ? " invalid" : "" ?>"
                           inputmode="numeric" maxlength="1" aria-label="Digit <?= $i + 1 ?>"
                           <?= $i === 0 ? 'autocomplete="one-time-code" autofocus' : 'autocomplete="off"' ?>>
                <?php endfor; ?>
            </div>

            <?php if ($code_error !== ""): ?>
                <div class="field-error"><?= htmlspecialchars($code_error) ?></div>
            <?php endif; ?>

            <button type="submit" class="btn-block">Verify &amp; Create Account</button>
        </form>

        <form method="POST" action="verify_email.php">
            <input type="hidden" name="action" value="resend">
            <button type="submit" class="btn-block btn-light" id="resendBtn" <?= $resend_wait > 0 ? "disabled" : "" ?>>
                Resend Code<?= $resend_wait > 0 ? " (" . $resend_wait . "s)" : "" ?>
            </button>
        </form>

        <a class="text-link" href="verify_email.php?cancel=1">Use a different Gmail address</a>

    </div>
</div>

<script>
var boxes = Array.prototype.slice.call(document.querySelectorAll(".otp-box"));
var hidden = document.getElementById("code");
var form = document.getElementById("verifyForm");

function sync() {
    hidden.value = boxes.map(function (b) { return b.value; }).join("");
}

boxes.forEach(function (box, i) {
    box.addEventListener("input", function () {
        box.value = box.value.replace(/\D/g, "").slice(-1);
        box.classList.remove("invalid");
        sync();
        if (box.value && i < boxes.length - 1) { boxes[i + 1].focus(); }
        if (hidden.value.length === 6) { form.submit(); }
    });

    box.addEventListener("keydown", function (e) {
        if (e.key === "Backspace" && !box.value && i > 0) {
            boxes[i - 1].value = "";
            boxes[i - 1].focus();
            sync();
        }
        if (e.key === "ArrowLeft" && i > 0) { boxes[i - 1].focus(); }
        if (e.key === "ArrowRight" && i < boxes.length - 1) { boxes[i + 1].focus(); }
    });

    box.addEventListener("focus", function () { box.select(); });

    box.addEventListener("paste", function (e) {
        e.preventDefault();
        var text = (e.clipboardData || window.clipboardData).getData("text").replace(/\D/g, "").slice(0, 6);
        text.split("").forEach(function (ch, k) { boxes[k].value = ch; });
        sync();
        boxes[Math.min(text.length, boxes.length - 1)].focus();
        if (text.length === 6) { form.submit(); }
    });
});

form.addEventListener("submit", function (e) {
    sync();
    if (hidden.value.length !== 6) {
        e.preventDefault();
        boxes.forEach(function (b) { if (!b.value) { b.classList.add("invalid"); } });
        (boxes.filter(function (b) { return !b.value; })[0] || boxes[0]).focus();
    }
});

var wait = <?= (int)$resend_wait ?>;
var btn = document.getElementById("resendBtn");
if (wait > 0) {
    var t = setInterval(function () {
        wait--;
        if (wait <= 0) { clearInterval(t); btn.disabled = false; btn.textContent = "Resend Code"; }
        else { btn.textContent = "Resend Code (" + wait + "s)"; }
    }, 1000);
}
</script>

</body>
</html>
