<?php

require_once "config.php";
requireAdmin();

$catalog = documentCatalog();

$counts = [];
$total_all = 0;

$res = $conn->query("SELECT document_type, COUNT(*) AS total, SUM(status = 'Pending') AS pending FROM document_requests GROUP BY document_type");
if ($res) {
    while ($r = $res->fetch_assoc()) {
        $counts[$r["document_type"]] = $r;
        $total_all += (int)$r["total"];
    }
}

$types = array_keys($catalog);
foreach (array_keys($counts) as $t) {
    if (!in_array($t, $types, true)) { $types[] = $t; }
}

$selected = trim($_GET["type"] ?? "");
if ($selected !== "" && !in_array($selected, $types, true)) { $selected = ""; }

$sql = "SELECT document_requests.*, users.name AS resident_name, users.email AS resident_email
        FROM document_requests
        INNER JOIN users ON document_requests.user_id = users.id";

if ($selected !== "") {
    $stmt = $conn->prepare($sql . " WHERE document_requests.document_type = ? ORDER BY document_requests.created_at DESC");
    $stmt->bind_param("s", $selected);
    $stmt->execute();
    $requests = $stmt->get_result();
} else {
    $requests = $conn->query($sql . " ORDER BY document_requests.created_at DESC");
}

$status_list = [];
$res = $conn->query("SELECT DISTINCT status FROM document_requests ORDER BY status");
if ($res) { while ($r = $res->fetch_assoc()) { $status_list[] = $r["status"]; } }
?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Document Requests - Barangay Mabuhay</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="stylesheet" href="style.css?v=<?= @filemtime(__DIR__ . '/style.css') ?>">
</head>

<body>

<?php include "nav.php"; ?>

<div class="container">

    <h1 class="page-title"><?= $selected !== "" ? htmlspecialchars($selected) . " Requests" : "All Document Requests" ?></h1>
    <p class="subtitle">
        <?= $selected !== "" ? "Showing only " . htmlspecialchars($selected) . " requests." : "Pick a document type to see only that kind of request." ?>
    </p>

    <div class="tabs">
        <a class="tab-link<?= $selected === "" ? " on" : "" ?>" href="admin_requests.php">All <span><?= $total_all ?></span></a>
        <?php foreach ($types as $t): ?>
            <a class="tab-link<?= $selected === $t ? " on" : "" ?>" href="admin_requests.php?type=<?= urlencode($t) ?>">
                <?= htmlspecialchars($t) ?> <span><?= (int)($counts[$t]["total"] ?? 0) ?></span>
            </a>
        <?php endforeach; ?>
    </div>

    <div class="toolbar">
        <div class="search-box">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
            <input type="search" placeholder="Search request no., resident, purpose..." data-filter-table="reqTable">
        </div>
        <select data-filter-status="reqTable" aria-label="Filter by status">
            <option value="">All statuses</option>
            <?php foreach ($status_list as $s): ?>
                <option value="<?= htmlspecialchars($s) ?>"><?= htmlspecialchars($s) ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="table-box">
        <table id="reqTable">
            <thead>
                <tr>
                    <th>Request No.</th>
                    <th>Resident</th>
                    <?php if ($selected === ""): ?><th>Document</th><?php endif; ?>
                    <th>Date</th>
                    <th>Payment</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($requests && $requests->num_rows > 0): ?>
                <?php while ($request = $requests->fetch_assoc()): ?>
                <tr data-status="<?= htmlspecialchars($request["status"]) ?>">
                    <td><?= htmlspecialchars($request["request_number"]) ?></td>
                    <td>
                        <?= htmlspecialchars($request["resident_name"]) ?>
                        <span class="cell-sub"><?= htmlspecialchars($request["purpose"] ?? "") ?></span>
                    </td>
                    <?php if ($selected === ""): ?><td><?= htmlspecialchars($request["document_type"]) ?></td><?php endif; ?>
                    <td><?= date("M d, Y", strtotime($request["created_at"])) ?></td>
                    <td><?= htmlspecialchars($request["payment_status"] ?? "-") ?></td>
                    <td><span class="status"><?= htmlspecialchars($request["status"]) ?></span></td>
                    <td><a href="admin_request.php?id=<?= $request["id"] ?>" class="view-btn">View</a></td>
                </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="7" style="text-align:center;color:var(--muted)">No document requests found.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>

<script src="ui.js?v=<?= @filemtime(__DIR__ . '/ui.js') ?>"></script>
</body>
</html>
