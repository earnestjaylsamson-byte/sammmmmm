
<?php

// Email OTP settings
define("OTP_ENABLED", true);
define("OTP_DEMO_MODE", false);

// Active email provider
define("MAIL_PROVIDER", "script");

// Google Apps Script deployment URL
define(
    "SCRIPT_URL",
    "https://script.google.com/macros/s/AKfycbz7YrhEsJBokLw4oyMbpjb4-d86_x8n0vsuipgcCT1ww9Yz1-OMM4LSbo2-kxTkbdhXyQ/exec"
);

// Development URL (not used for normal production sending)
define(
    "SCRIPT_DEV_URL",
    "https://script.google.com/macros/s/AKfycbx1rcmWjLmj7Wyz6qtwgRv0jno-AedU8fJVD10Ft7u-/dev"
);

// Must exactly match the secret in Google Apps Script
define("SCRIPT_SECRET", "REPLACE_WITH_YOUR_NEW_SECRET");

// Admin email for OTP notifications, if used by mailer.php
define("ADMIN_OTP_EMAIL", "samsonearnestjay@smcbi.edu.ph");

// Brevo fallback credentials (not active while MAIL_PROVIDER is "script")
define("BREVO_API_KEY", "");
define("BREVO_SENDER_EMAIL", "");

// SMTP fallback credentials (not active while MAIL_PROVIDER is "script")
define("SMTP_HOST", "smtp.gmail.com");
define("SMTP_PORT", 465);
define("SMTP_USER", "");
define("SMTP_PASS", "");

// Email sender display name
define("MAIL_FROM_NAME", "Barangay Mabuhay");

// OTP security settings
define("OTP_EXPIRY_MINUTES", 10);
define("OTP_MAX_ATTEMPTS", 5);
define("OTP_RESEND_SECONDS", 60);

// Keep false for normal use.
// Temporarily set true only when diagnosing email errors.
define("SMTP_DEBUG", true);
