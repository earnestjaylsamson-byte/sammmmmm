<?php
/*
 * Tiny SMTP mailer (Gmail over SSL) + login-code helpers. No libraries needed.
 */
require_once __DIR__ . "/mail_config.php";

const ADMIN_ROLES = ["admin", "barangay_admin", "staff", "secretary", "system_admin"];

function otpConfigured() {
    if (MAIL_PROVIDER === "script") {
        return strpos(SCRIPT_URL, "https://script.google.com/") === 0
            && SCRIPT_SECRET !== "" && SCRIPT_SECRET !== "type-any-secret-word-here";
    }
    if (MAIL_PROVIDER === "brevo") {
        return BREVO_API_KEY !== "" && BREVO_API_KEY !== "paste-your-brevo-api-key-here"
            && filter_var(BREVO_SENDER_EMAIL, FILTER_VALIDATE_EMAIL) && BREVO_SENDER_EMAIL !== "your.email@example.com";
    }
    return SMTP_USER !== "" && SMTP_USER !== "your.gmail@gmail.com" && SMTP_PASS !== "" && SMTP_PASS !== "xxxx xxxx xxxx xxxx";
}

// Sends one email with whichever service is chosen in mail_config.php
function smtpSend($to, $subject, $html, $text, &$error = null) {
    if (MAIL_PROVIDER === "script") {
        return scriptSend($to, $subject, $html, $text, $error);
    }
    if (MAIL_PROVIDER === "brevo") {
        return brevoSend($to, $subject, $html, $text, $error);
    }
    return gmailSend($to, $subject, $html, $text, $error);
}

// Sends through the owner's own Gmail using a small Google Apps Script (see gmail-script.txt)
function scriptSend($to, $subject, $html, $text, &$error = null) {

    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid recipient email.";
        return false;
    }

    if (!function_exists("curl_init")) {
        $error = "This server has no cURL, so it cannot call the Google script.";
        return false;
    }

    $payload = json_encode([
        "secret"   => SCRIPT_SECRET,
        "to"       => $to,
        "subject"  => $subject,
        "html"     => $html,
        "text"     => $text,
        "fromName" => MAIL_FROM_NAME
    ]);

    $ch = curl_init(SCRIPT_URL);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_HTTPHEADER     => ["Content-Type: application/json"],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS      => 5,
        CURLOPT_TIMEOUT        => 30
    ]);
    $response = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    if ($response === false) {
        $error = "Could not reach the Google script (" . $curl_error . ").";
        return false;
    }

    $data = json_decode($response, true);

    if (is_array($data) && !empty($data["ok"])) {
        return true;
    }

    if (is_array($data) && isset($data["error"])) {
        $error = "Google script said: " . $data["error"];
    } else {
        $error = "Unexpected reply from the Google script (HTTP " . $status . "). Check that it is deployed as a Web app with access set to Anyone.";
    }

    return false;
}

function brevoSend($to, $subject, $html, $text, &$error = null) {

    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid recipient email.";
        return false;
    }

    $payload = json_encode([
        "sender"      => ["name" => MAIL_FROM_NAME, "email" => BREVO_SENDER_EMAIL],
        "to"          => [["email" => $to]],
        "subject"     => $subject,
        "htmlContent" => $html,
        "textContent" => $text
    ]);

    $headers = ["accept: application/json", "content-type: application/json", "api-key: " . BREVO_API_KEY];
    $url = "https://api.brevo.com/v3/smtp/email";
    $status = 0;

    if (function_exists("curl_init")) {

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $payload,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 20
        ]);
        $response = curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        curl_close($ch);

        if ($response === false) {
            $error = "Could not reach Brevo (" . $curl_error . ").";
            return false;
        }

    } else {

        $context = stream_context_create(["http" => [
            "method" => "POST", "header" => implode("\r\n", $headers),
            "content" => $payload, "timeout" => 20, "ignore_errors" => true
        ]]);
        $response = @file_get_contents($url, false, $context);

        if ($response === false) {
            $error = "Could not reach Brevo.";
            return false;
        }

        if (isset($http_response_header[0]) && preg_match("/\s(\d{3})\s/", $http_response_header[0], $found)) {
            $status = (int)$found[1];
        }
    }

    if ($status >= 200 && $status < 300) {
        return true;
    }

    $data = json_decode($response, true);
    $error = "Brevo replied (" . $status . "): " . ($data["message"] ?? trim($response));
    return false;
}

function gmailSend($to, $subject, $html, $text, &$error = null) {

    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid recipient email.";
        return false;
    }

    $fp = @stream_socket_client("ssl://" . SMTP_HOST . ":" . SMTP_PORT, $errno, $errstr, 15);

    if (!$fp) {
        $error = "Could not connect to the mail server (" . $errstr . ").";
        return false;
    }

    stream_set_timeout($fp, 15);

    $read = function () use ($fp) {
        $data = "";
        while (($line = fgets($fp, 515)) !== false) {
            $data .= $line;
            if (strlen($line) < 4 || $line[3] === " ") { break; }
        }
        return $data;
    };

    $step = function ($command, $expect) use ($fp, $read, &$error) {
        if ($command !== null) { fwrite($fp, $command . "\r\n"); }
        $reply = $read();
        if (strpos($reply, (string)$expect) !== 0) {
            $error = "Mail server replied: " . trim($reply);
            return false;
        }
        return true;
    };

    $from = SMTP_USER;
    $pass = str_replace(" ", "", SMTP_PASS);
    $host = $_SERVER["HTTP_HOST"] ?? "localhost";

    $boundary = "b" . bin2hex(random_bytes(8));

    $headers  = "Date: " . date("r") . "\r\n";
    $headers .= "From: =?UTF-8?B?" . base64_encode(MAIL_FROM_NAME) . "?= <" . $from . ">\r\n";
    $headers .= "To: <" . $to . ">\r\n";
    $headers .= "Subject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\n";
    $headers .= "Message-ID: <" . bin2hex(random_bytes(8)) . "@" . preg_replace("/[^a-z0-9.\-]/i", "", $host) . ">\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: multipart/alternative; boundary=\"" . $boundary . "\"\r\n";

    $body  = "--" . $boundary . "\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n";
    $body .= chunk_split(base64_encode($text));
    $body .= "--" . $boundary . "\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n";
    $body .= chunk_split(base64_encode($html));
    $body .= "--" . $boundary . "--\r\n";

    $ok =
        $step(null, 220) &&
        $step("EHLO " . preg_replace("/[^a-z0-9.\-]/i", "", $host), 250) &&
        $step("AUTH LOGIN", 334) &&
        $step(base64_encode($from), 334) &&
        $step(base64_encode($pass), 235) &&
        $step("MAIL FROM:<" . $from . ">", 250) &&
        $step("RCPT TO:<" . $to . ">", 250) &&
        $step("DATA", 354);

    if ($ok) {
        fwrite($fp, $headers . "\r\n" . $body . "\r\n.\r\n");
        $ok = $step(null, 250);
    }

    if ($ok) {
        fwrite($fp, "QUIT\r\n");
    }

    fclose($fp);

    if ($error && strpos($error, "535") !== false) {
        $error .= " (Check SMTP_USER and the Gmail App Password in mail_config.php.)";
    }

    return $ok;
}

function otpEmailBody($name, $code, $purpose = "login") {
    $name = htmlspecialchars($name);
    $mins = OTP_EXPIRY_MINUTES;

    if ($purpose === "register") {
        $intro = "Your verification code to finish creating your Barangay Mabuhay account is:";
        $ignore = "If you did not try to create an account, you can ignore this message.";
    } else {
        $intro = "Your Barangay Mabuhay login code is:";
        $ignore = "If you did not try to log in, you can ignore this message.";
    }

    // Short, plain, no links and no images: this style is the least likely to be treated as spam.
    $html = '<div style="font-family:Arial,Helvetica,sans-serif;font-size:15px;color:#222;line-height:1.5;max-width:480px">'
        . '<p>Hi ' . $name . ',</p>'
        . '<p>' . $intro . '</p>'
        . '<p style="font-size:30px;font-weight:bold;letter-spacing:6px;color:#1f4aa8;margin:16px 0">' . $code . '</p>'
        . '<p>This code expires in ' . $mins . ' minutes. ' . $ignore . '</p>'
        . '<p style="color:#666">Barangay Mabuhay, Bansalan</p>'
        . '</div>';

    $text = "Hi " . $name . ",\n\n" . $intro . "\n\n" . $code . "\n\nThis code expires in " . $mins . " minutes. " . $ignore . "\n\nBarangay Mabuhay, Bansalan\n";

    return [$html, $text];
}

// Creates a code, emails it, and remembers it (hashed) in the session until it is verified.
function startLoginVerification($user, &$error = null) {

    $code = str_pad((string)random_int(0, 999999), 6, "0", STR_PAD_LEFT);

    $to = $user["email"];
    if (in_array($user["role"], ADMIN_ROLES, true) && ADMIN_OTP_EMAIL !== "") {
        $to = ADMIN_OTP_EMAIL;
    }

    list($html, $text) = otpEmailBody($user["name"], $code);

    if (!smtpSend($to, "Your Barangay Mabuhay login code: " . $code, $html, $text, $error)) {
        return false;
    }

    $_SESSION["pending_login"] = [
        "id"        => $user["id"],
        "name"      => $user["name"],
        "email"     => $user["email"],
        "role"      => $user["role"],
        "sent_to"   => $to,
        "code_hash" => password_hash($code, PASSWORD_DEFAULT),
        "expires"   => time() + OTP_EXPIRY_MINUTES * 60,
        "attempts"  => 0,
        "sent_at"   => time()
    ];

    return true;
}

// Logs the user in for real and sends them to the right dashboard.
function completeLogin($user) {

    session_regenerate_id(true);

    unset($_SESSION["pending_login"]);

    $_SESSION["user_id"]    = $user["id"];
    $_SESSION["user_name"]  = $user["name"];
    $_SESSION["user_email"] = $user["email"];
    $_SESSION["role"]       = $user["role"];

    header("Location: " . (in_array($user["role"], ADMIN_ROLES, true) ? "admin.php" : "dashboard.php"));
    exit();
}

function maskEmail($email) {
    $parts = explode("@", $email, 2);
    if (count($parts) !== 2) { return $email; }
    $local = $parts[0];
    $shown = substr($local, 0, min(2, strlen($local)));
    return $shown . str_repeat("*", max(2, strlen($local) - strlen($shown))) . "@" . $parts[1];
}


// Sends a code to a NEW person's email and holds their sign-up details (not saved to the database yet).
function startRegistrationVerification($name, $email, $password_hash, &$error = null) {

    $code = str_pad((string)random_int(0, 999999), 6, "0", STR_PAD_LEFT);
    $demo_code = null;
    $send_error = "";

    if (OTP_DEMO_MODE && !otpConfigured()) {

        // No Gmail set up yet: show the code on the next page instead of emailing it.
        $demo_code = $code;
        $send_error = "SMTP_USER / SMTP_PASS in mail_config.php are still the placeholder values.";

    } else {

        list($html, $text) = otpEmailBody($name, $code, "register");

        if (!smtpSend($email, "Your Barangay Mabuhay verification code: " . $code, $html, $text, $error)) {

            if (!OTP_DEMO_MODE) {
                return false;
            }

            $demo_code = $code;
            $send_error = (string)$error;
        }
    }

    $_SESSION["pending_register"] = [
        "name"          => $name,
        "email"         => $email,
        "password_hash" => $password_hash,
        "sent_to"       => $email,
        "code_hash"     => password_hash($code, PASSWORD_DEFAULT),
        "demo_code"     => $demo_code,
        "mail_error"    => $send_error,
        "expires"       => time() + OTP_EXPIRY_MINUTES * 60,
        "attempts"      => 0,
        "sent_at"       => time()
    ];

    return true;
}

// Saves the verified resident in the database.
function createResident($conn, $name, $email, $password_hash, &$error = null) {

    $check = $conn->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");

    if (!$check) {
        $error = "Database error: " . $conn->error;
        return false;
    }

    $check->bind_param("s", $email);
    $check->execute();

    if ($check->get_result()->num_rows > 0) {
        $check->close();
        $error = "This email is already registered. Please log in.";
        return false;
    }

    $check->close();

    $stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'resident')");

    if (!$stmt) {
        $error = "Database error: " . $conn->error;
        return false;
    }

    $stmt->bind_param("sss", $name, $email, $password_hash);

    if (!$stmt->execute()) {
        $error = "Registration failed: " . $stmt->error;
        $stmt->close();
        return false;
    }

    $stmt->close();
    return true;
}
