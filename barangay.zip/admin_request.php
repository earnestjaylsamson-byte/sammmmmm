<?php

require_once "config.php";

requireAdmin();

$id = intval($_GET["id"] ?? 0);

if ($id <= 0) {
    header("Location: admin_requests.php");
    exit();
}

$message = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $action = $_POST["action"] ?? "";

    if ($action === "update_status") {

        $status = $_POST["status"] ?? "";
        $remarks = trim($_POST["remarks"] ?? "");

        $allowed_statuses = [
            "Pending",
            "Under Review",
            "Approved",
            "Rejected",
            "Payment Required",
            "Payment Confirmed",
            "Processing",
            "Completed",
            "Ready for Pickup"
        ];

        if (in_array($status, $allowed_statuses)) {

            $stmt = $conn->prepare("
                UPDATE document_requests
                SET status = ?, remarks = ?
                WHERE id = ?
            ");

            $stmt->bind_param("ssi", $status, $remarks, $id);
            $stmt->execute();
            $stmt->close();

            $message = "Request status updated successfully.";

        } else {

            $error = "Invalid request status.";

        }

    }

    if ($action === "verify_payment") {

        $stmt = $conn->prepare("
            UPDATE payments
            SET status = 'Verified'
            WHERE request_id = ?
        ");

        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();

        $stmt = $conn->prepare("
            UPDATE document_requests
            SET payment_status = 'Verified',
                status = 'Payment Confirmed'
            WHERE id = ?
        ");

        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();

        $message = "Payment verified successfully.";

    }

    if ($action === "upload_document") {

        if (isset($_FILES["document"]) && $_FILES["document"]["error"] === UPLOAD_ERR_OK) {

            $file = $_FILES["document"];

            $extension = strtolower(pathinfo($file["name"], PATHINFO_EXTENSION));

            if ($extension !== "pdf") {

                $error = "Only PDF documents are allowed.";

            } else {

                $folder = "uploads/documents/";

                if (!is_dir($folder)) {
                    mkdir($folder, 0755, true);
                }

                $filename = "document_" . $id . "_" . time() . ".pdf";

                $destination = $folder . $filename;

                if (move_uploaded_file($file["tmp_name"], $destination)) {

                    $stmt = $conn->prepare("
                        UPDATE document_requests
                        SET document_file = ?,
                            status = 'Completed'
                        WHERE id = ?
                    ");

                    $stmt->bind_param("si", $destination, $id);
                    $stmt->execute();
                    $stmt->close();

                    $message = "PDF document uploaded successfully.";

                } else {

                    $error = "Unable to upload the document.";

                }

            }

        } else {

            $error = "Please select a PDF document.";

        }

    }
}

$stmt = $conn->prepare("
    SELECT 
        document_requests.*,
        users.name AS resident_name,
        users.email AS resident_email
    FROM document_requests
    INNER JOIN users ON document_requests.user_id = users.id
    WHERE document_requests.id = ?
    LIMIT 1
");

$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    header("Location: admin_requests.php");
    exit();
}

$request = $result->fetch_assoc();

$stmt->close();

$payment = null;

$stmt = $conn->prepare("
    SELECT *
    FROM payments
    WHERE request_id = ?
    ORDER BY id DESC
    LIMIT 1
");

$stmt->bind_param("i", $id);
$stmt->execute();

$payment_result = $stmt->get_result();

if ($payment_result->num_rows === 1) {
    $payment = $payment_result->fetch_assoc();
}

$stmt->close();

?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Barangay Mabuhay - Request Details</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="stylesheet" href="style.css?v=<?= @filemtime(__DIR__ . '/style.css') ?>">
</head>

<body>

<?php include "nav.php"; ?>

<div class="container">

    <h1 class="page-title">Request Details</h1>

    <?php if ($message !== ""): ?>

        <div class="message">
            <?= htmlspecialchars($message) ?>
        </div>

    <?php endif; ?>

    <?php if ($error !== ""): ?>

        <div class="error">
            <?= htmlspecialchars($error) ?>
        </div>

    <?php endif; ?>

    <div class="card">

        <h2>
            <?= htmlspecialchars($request["request_number"]) ?>
        </h2>

        <div class="detail-grid">

            <div class="detail">
                <strong>Resident</strong>
                <?= htmlspecialchars($request["resident_name"]) ?>
            </div>

            <div class="detail">
                <strong>Email</strong>
                <?= htmlspecialchars($request["resident_email"]) ?>
            </div>

            <div class="detail">
                <strong>Document</strong>
                <?= htmlspecialchars($request["document_type"]) ?>
            </div>

            <?php foreach ([
                "Full Name" => "full_name", "Age" => "age", "Sex" => "sex",
                "Civil Status" => "civil_status", "Contact Number" => "contact_number", "Address" => "address"
            ] as $label => $col): if (!empty($request[$col])): ?>
            <div class="detail">
                <strong><?= $label ?></strong>
                <?= htmlspecialchars($request[$col]) ?>
            </div>
            <?php endif; endforeach; ?>

            <div class="detail">
                <strong>Purpose</strong>
                <?= htmlspecialchars($request["purpose"]) ?>
            </div>

            <div class="detail">
                <strong>Amount</strong>
                ₱<?= number_format((float)$request["amount"], 2) ?>
            </div>

            <div class="detail">
                <strong>Request Status</strong>
                <?= htmlspecialchars($request["status"]) ?>
            </div>

            <div class="detail">
                <strong>Payment Status</strong>
                <?= htmlspecialchars($request["payment_status"]) ?>
            </div>

            <div class="detail">
                <strong>Date Submitted</strong>
                <?= htmlspecialchars($request["created_at"]) ?>
            </div>

        </div>

    </div>

    <div class="card">

        <h2>Update Request</h2>

        <form method="POST">

            <input type="hidden" name="action" value="update_status">

            <div class="form-group">

                <label>Status</label>

                <select name="status" required>

                    <option value="Pending">Pending</option>
                    <option value="Under Review">Under Review</option>
                    <option value="Approved">Approved</option>
                    <option value="Rejected">Rejected</option>
                    <option value="Payment Required">Payment Required</option>
                    <option value="Payment Confirmed">Payment Confirmed</option>
                    <option value="Processing">Processing</option>
                    <option value="Completed">Completed</option>
                    <option value="Ready for Pickup">Ready for Pickup</option>

                </select>

            </div>

            <div class="form-group">

                <label>Remarks</label>

                <textarea name="remarks"><?= htmlspecialchars($request["remarks"] ?? "") ?></textarea>

            </div>

            <button type="submit" class="btn btn-green">
                Update Request
            </button>

        </form>

    </div>

    <div class="card">

        <h2>Payment</h2>

        <?php if ($payment): ?>

            <div class="detail-grid">

                <div class="detail">
                    <strong>Reference Number</strong>
                    <?= htmlspecialchars($payment["reference_number"] ?? "N/A") ?>
                </div>

                <div class="detail">
                    <strong>Payment Status</strong>
                    <?= htmlspecialchars($payment["status"] ?? "N/A") ?>
                </div>

                <div class="detail">
                    <strong>Amount</strong>
                    ₱<?= number_format((float)($payment["amount"] ?? 0), 2) ?>
                </div>

                <div class="detail">
                    <strong>Payment Date</strong>
                    <?= htmlspecialchars($payment["created_at"] ?? "N/A") ?>
                </div>

            </div>

            <?php if (($payment["status"] ?? "") !== "Verified"): ?>

                <form method="POST" class="actions">

                    <input type="hidden" name="action" value="verify_payment">

                    <button type="submit" class="btn btn-green">
                        Verify Payment
                    </button>

                </form>

            <?php endif; ?>

        <?php else: ?>

            <p>No payment record found.</p>

        <?php endif; ?>

    </div>

    <div class="card">

        <h2>Completed Document</h2>

        <?php if (!empty($request["document_file"])): ?>

            <p>
                The completed PDF document is available.
            </p>

            <a
                href="<?= htmlspecialchars($request["document_file"]) ?>"
                target="_blank"
                class="btn btn-blue"
            >
                View PDF
            </a>

        <?php else: ?>

            <p>No completed document has been uploaded.</p>

            <form method="POST" enctype="multipart/form-data">

                <input type="hidden" name="action" value="upload_document">

                <div class="form-group">

                    <label>Upload PDF Document</label>

                    <input
                        type="file"
                        name="document"
                        accept=".pdf,application/pdf"
                        required
                    >

                </div>

                <button type="submit" class="btn btn-green">
                    Upload Document
                </button>

            </form>

        <?php endif; ?>

    </div>

    <a href="admin_requests.php" class="btn btn-green">
        Back to Requests
    </a>

</div>

<script src="ui.js"></script>
</body>
</html>