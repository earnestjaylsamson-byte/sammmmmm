<?php

session_start();

$host = "sql208.infinityfree.com";
$username = "if0_42969620";
$password = "739184620517";
$database = "if0_42969620_barangaysystem";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

function requireLogin() {
    if (!isset($_SESSION["user_id"])) {
        header("Location: login.php");
        exit();
    }
}

function requireAdmin() {
    requireLogin();

    $allowed_roles = [
        "admin",
        "barangay_admin",
        "staff",
        "secretary",
        "system_admin"
    ];

    if (!isset($_SESSION["role"]) || !in_array($_SESSION["role"], $allowed_roles)) {
        header("Location: dashboard.php");
        exit();
    }
}

function generateRequestNumber() {
    return "REQ-" . date("YmdHis") . "-" . rand(100, 999);
}


// Adds the resident-information columns to document_requests if they don't exist yet.
function ensureRequestColumns($conn) {
    $columns = [
        "full_name"      => "VARCHAR(150) NULL",
        "age"            => "INT NULL",
        "sex"            => "VARCHAR(20) NULL",
        "civil_status"   => "VARCHAR(30) NULL",
        "contact_number" => "VARCHAR(30) NULL",
        "address"        => "VARCHAR(255) NULL"
    ];

    foreach ($columns as $name => $definition) {
        $check = $conn->query("SHOW COLUMNS FROM document_requests LIKE '" . $name . "'");

        if ($check && $check->num_rows === 0) {
            $conn->query("ALTER TABLE document_requests ADD COLUMN $name $definition");
        }
    }
}


// Documents residents can request, and their fees (edit prices here).
function documentCatalog() {
    return [
        "Barangay Clearance"       => 50,
        "Certificate of Residency" => 50,
        "Certificate of Indigency" => 0,
        "Barangay Certification"   => 50,
        "Cedula"                   => 50
    ];
}

function isAdminRole($role) {
    return in_array($role, ["admin", "barangay_admin", "staff", "secretary", "system_admin"], true);
}

// Adds the residency-verification columns to the users table if they don't exist yet.
function ensureUserColumns($conn) {
    $columns = [
        "verification_status"       => "VARCHAR(20) NOT NULL DEFAULT 'Unverified'",
        "purok"                     => "VARCHAR(100) NULL",
        "address"                   => "VARCHAR(255) NULL",
        "id_file"                   => "VARCHAR(255) NULL",
        "verification_note"         => "VARCHAR(255) NULL",
        "verification_submitted_at" => "DATETIME NULL",
        "verified_at"               => "DATETIME NULL"
    ];

    $existing = [];
    $result = $conn->query("SHOW COLUMNS FROM users");

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $existing[] = $row["Field"];
        }
    }

    foreach ($columns as $name => $definition) {
        if (!in_array($name, $existing, true)) {
            $conn->query("ALTER TABLE users ADD COLUMN $name $definition");
        }
    }
}

// Returns Unverified, Pending, Verified or Rejected.
function getVerificationStatus($conn, $user_id, $ensure = false) {
    try {
        if ($ensure) {
            ensureUserColumns($conn);
        }

        $stmt = $conn->prepare("SELECT verification_status FROM users WHERE id = ? LIMIT 1");

        if (!$stmt) {
            return "Unverified";
        }

        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        return $row["verification_status"] ?? "Unverified";

    } catch (Throwable $e) {
        return "Unverified";
    }
}

// Residents must be verified as living in the barangay before they can request documents.
function requireVerifiedResident($conn) {
    requireLogin();

    if (isAdminRole($_SESSION["role"] ?? "")) {
        return;
    }

    if (getVerificationStatus($conn, $_SESSION["user_id"], true) !== "Verified") {
        header("Location: verify_residency.php?need=1");
        exit();
    }
}

?>