<?php

require_once "config.php";
requireLogin();

$id = isset($_GET["id"]) ? intval($_GET["id"]) : 0;

$stmt = $conn->prepare("
    SELECT *
    FROM document_requests
    WHERE id = ? AND user_id = ?
    LIMIT 1
");

$stmt->bind_param("ii", $id, $_SESSION["user_id"]);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    die("Request not found.");
}

$request = $result->fetch_assoc();

$payment = null;

$payment_stmt = $conn->prepare("
    SELECT *
    FROM payments
    WHERE request_id = ?
    AND user_id = ?
    ORDER BY id DESC
    LIMIT 1
");

$payment_stmt->bind_param(
    "ii",
    $request["id"],
    $_SESSION["user_id"]
);

$payment_stmt->execute();

$payment_result = $payment_stmt->get_result();

if ($payment_result->num_rows === 1) {
    $payment = $payment_result->fetch_assoc();
}

$document_file = "";

if (isset($request["document_file"]) && !empty($request["document_file"])) {
    $document_file = $request["document_file"];
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>View Request - Barangay Mabuhay</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="stylesheet" href="style.css?v=<?= @filemtime(__DIR__ . '/style.css') ?>">
</head>

<body class="narrow">

<?php include "nav.php"; ?>

<div class="container">

    <div class="box">

        <h1>Request Details</h1>

        <div class="detail">

            <strong>Request Number</strong>

            <?php
            echo htmlspecialchars(
                $request["request_number"]
            );
            ?>

        </div>

        <div class="detail">

            <strong>Document</strong>

            <?php
            echo htmlspecialchars(
                $request["document_type"]
            );
            ?>

        </div>

        <?php foreach ([
            "Full Name" => "full_name", "Age" => "age", "Sex" => "sex",
            "Civil Status" => "civil_status", "Contact Number" => "contact_number", "Address" => "address"
        ] as $label => $col): if (!empty($request[$col])): ?>
        <div class="detail">
            <strong><?= $label ?></strong>
            <?= htmlspecialchars($request[$col]) ?>
        </div>
        <?php endif; endforeach; ?>

        <div class="detail">

            <strong>Purpose</strong>

            <?php
            echo htmlspecialchars(
                $request["purpose"]
            );
            ?>

        </div>

        <div class="detail">

            <strong>Amount</strong>

            ₱<?php
            echo number_format(
                $request["amount"],
                2
            );
            ?>

        </div>

        <div class="detail">

            <strong>Request Status</strong>

            <span class="status">

                <?php
                echo htmlspecialchars(
                    $request["status"]
                );
                ?>

            </span>

        </div>

        <div class="detail">

            <strong>Payment Status</strong>

            <?php
            echo htmlspecialchars(
                $request["payment_status"]
            );
            ?>

        </div>

        <div class="detail">

            <strong>Submitted</strong>

            <?php
            echo date(
                "M d, Y h:i A",
                strtotime($request["created_at"])
            );
            ?>

        </div>


        <?php if (
            floatval($request["amount"]) > 0 &&
            $request["status"] === "Payment Required" &&
            (
                !$payment ||
                $payment["status"] === "Rejected"
            )
        ): ?>

            <div class="payment-required-box">

                <h2>Payment Required</h2>

                <p>
                    Your document request requires payment.
                    You can choose GCash or Cash on Delivery, then pick Pickup or Delivery.
                    You may change your payment method while choosing,
                    but once payment is submitted, the method will be locked.
                </p>

                <div class="payment-amount">

                    <small>
                        Amount to Pay
                    </small>

                    <strong>
                        ₱<?php
                        echo number_format(
                            $request["amount"],
                            2
                        );
                        ?>
                    </strong>

                </div>

                <a
                    href="payment.php?id=<?php echo $request["id"]; ?>"
                    class="payment-button"
                >
                    Choose Payment Method
                </a>

            </div>

        <?php endif; ?>


        <?php if ($payment): ?>

            <div class="payment-status-box">

                <h2>
                    Payment Information
                </h2>

                <p>

                    <strong>
                        Payment Method:
                    </strong>

                    <?php
                    echo htmlspecialchars(
                        $payment["payment_method"]
                    );
                    ?>

                </p>


                <?php if (
                    isset($payment["delivery_method"]) &&
                    $payment["delivery_method"] !== ""
                ): ?>

                    <p>

                        <strong>
                            Delivery Method:
                        </strong>

                        <?php
                        echo htmlspecialchars(
                            $payment["delivery_method"]
                        );
                        ?>

                    </p>

                <?php endif; ?>


                <?php if (
                    isset($payment["delivery_address"]) &&
                    $payment["delivery_address"] !== ""
                ): ?>

                    <p>

                        <strong>
                            Delivery Address:
                        </strong>

                        <?php
                        echo nl2br(
                            htmlspecialchars(
                                $payment["delivery_address"]
                            )
                        );
                        ?>

                    </p>

                <?php endif; ?>


                <p>

                    <strong>
                        Reference Number:
                    </strong>

                    <?php
                    echo htmlspecialchars(
                        $payment["reference_number"] ?? "N/A"
                    );
                    ?>

                </p>


                <p>

                    <strong>
                        Amount:
                    </strong>

                    ₱<?php
                    echo number_format(
                        $payment["amount"],
                        2
                    );
                    ?>

                </p>


                <p>

                    <strong>
                        Payment Date:
                    </strong>

                    <?php
                    if (
                        isset($payment["created_at"]) &&
                        !empty($payment["created_at"])
                    ) {
                        echo date(
                            "F d, Y h:i A",
                            strtotime($payment["created_at"])
                        );
                    } else {
                        echo "N/A";
                    }
                    ?>

                </p>


                <p>

                    <strong>
                        Payment Status:
                    </strong>

                    <?php if (
                        $payment["status"] === "Pending Verification"
                    ): ?>

                        <span class="pending-payment">
                            Pending Verification
                        </span>

                    <?php elseif (
                        $payment["status"] === "Verified"
                    ): ?>

                        <span class="verified-payment">
                            Verified
                        </span>

                    <?php elseif (
                        $payment["status"] === "Rejected"
                    ): ?>

                        <span class="rejected-payment">
                            Rejected
                        </span>

                    <?php elseif (
                        $payment["status"] === "COD Pending"
                    ): ?>

                        <span class="cod-payment">
                            COD Pending
                        </span>

                    <?php else: ?>

                        <?php
                        echo htmlspecialchars(
                            $payment["status"]
                        );
                        ?>

                    <?php endif; ?>

                </p>


                <?php if (
                    $payment["status"] === "Pending Verification"
                ): ?>

                    <div class="waiting-box">

                        <strong>
                            Payment Submitted Successfully.
                        </strong>

                        <br>

                        Your GCash payment has been submitted and is now
                        waiting for barangay staff approval.

                        <br><br>

                        Please wait while the barangay staff reviews and
                        verifies your payment.

                    </div>

                    <div class="locked-payment-box">

                        Your payment method is locked while your payment
                        is waiting for barangay staff approval.

                    </div>

                <?php elseif (
                    $payment["status"] === "COD Pending"
                ): ?>

                    <div class="waiting-box">

                        <strong>
                            Payment Option Submitted Successfully.
                        </strong>

                        <br>

                        Your Cash on Delivery request has been submitted
                        and is now waiting for barangay staff approval.

                        <br><br>

                        Please wait while the barangay staff reviews and
                        confirms your payment request.

                    </div>

                    <div class="locked-payment-box">

                        Your payment method is locked while your payment
                        is waiting for barangay staff approval.

                    </div>

                <?php elseif (
                    $payment["status"] === "Verified"
                ): ?>

                    <div class="verified-box">

                        <strong>
                            Payment Approved.
                        </strong>

                        <br>

                        Your payment has been verified and approved by
                        the barangay staff.

                        <br><br>

                        Your document request can now proceed to processing.

                    </div>

                    <div class="locked-payment-box">

                        Your payment method is locked because payment
                        has already been submitted and verified.

                    </div>

                <?php elseif (
                    $payment["status"] === "Rejected"
                ): ?>

                    <div class="rejected-box">

                        <strong>
                            Payment Rejected.
                        </strong>

                        <br>

                        Your payment was not verified by the barangay staff.

                        <br><br>

                        You may choose a payment method again and submit
                        a new payment.

                    </div>

                <?php endif; ?>

            </div>

        <?php endif; ?>


        <?php if (
            $request["status"] === "Completed" &&
            !empty($document_file)
        ): ?>

            <div class="document-box">

                <h2>
                    Completed Document
                </h2>

                <p>
                    Your requested document has been completed and is now
                    available as a PDF.
                </p>

                <iframe
                    class="pdf-viewer"
                    src="<?php echo htmlspecialchars($document_file); ?>"
                    title="Completed Document PDF"
                ></iframe>

                <div class="document-buttons">

                    <a
                        href="<?php echo htmlspecialchars($document_file); ?>"
                        target="_blank"
                        class="document-button"
                    >
                        View PDF
                    </a>

                    <a
                        href="<?php echo htmlspecialchars($document_file); ?>"
                        download
                        class="document-button download-button"
                    >
                        Download PDF
                    </a>

                </div>

            </div>

        <?php elseif (
            $request["status"] === "Completed" &&
            empty($document_file)
        ): ?>

            <div class="document-waiting">

                <h2>
                    Document Completed
                </h2>

                The request has been marked as completed, but the PDF
                document is not currently available.

                <br><br>

                Please wait for the barangay staff to upload the completed
                document.

            </div>

        <?php endif; ?>


        <?php if (
            $request["status"] !== "Payment Required" &&
            !$payment &&
            floatval($request["amount"]) > 0
        ): ?>

            <div class="no-payment-box">

                Payment is not currently required.
                Please wait for the barangay staff to update your request.

            </div>

        <?php endif; ?>


        <a
            href="my_requests.php"
            class="back-btn"
        >
            Back to My Requests
        </a>

    </div>

</div>

<script src="ui.js"></script>
</body>

</html>