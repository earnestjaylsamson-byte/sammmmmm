<?php

require_once "config.php";

$name = "Barangay Admin";
$email = "admin@civiclink.com";
$password = "Admin12345";
$role = "admin";

$check = $conn->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
$check->bind_param("s", $email);
$check->execute();

$result = $check->get_result();

if ($result->num_rows > 0) {

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("
        UPDATE users
        SET name = ?, password = ?, role = ?
        WHERE email = ?
    ");

    $stmt->bind_param(
        "ssss",
        $name,
        $hashed_password,
        $role,
        $email
    );

    if ($stmt->execute()) {
        echo "Admin account updated successfully.";
    } else {
        echo "Error updating admin: " . $stmt->error;
    }

    $stmt->close();

} else {

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("
        INSERT INTO users (name, email, password, role)
        VALUES (?, ?, ?, ?)
    ");

    $stmt->bind_param(
        "ssss",
        $name,
        $email,
        $hashed_password,
        $role
    );

    if ($stmt->execute()) {
        echo "Admin account created successfully.";
    } else {
        echo "Error creating admin: " . $stmt->error;
    }

    $stmt->close();
}

$check->close();

?>