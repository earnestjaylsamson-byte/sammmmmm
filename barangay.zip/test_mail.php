<?php
/*
 * TEMPORARY helper — checks why the Gmail code is not arriving.
 * Open  yoursite/test_mail.php , press the button, read the result. DELETE THIS FILE AFTERWARDS.
 * It only ever sends a test email to the Gmail address you put in mail_config.php (ADMIN_OTP_EMAIL).
 */
ini_set("display_errors", 1);
error_reporting(E_ALL);

require_once __DIR__ . "/mail_config.php";
require_once __DIR__ . "/mailer.php";

function row($ok, $label, $detail = "") {
    echo '<tr><td style="color:' . ($ok ? "#137a4b" : "#d11c23") . ';font-weight:bold">' . ($ok ? "OK" : "PROBLEM") . '</td><td>'
        . htmlspecialchars($label) . '</td><td>' . htmlspecialchars($detail) . '</td></tr>';
}

echo '<body style="font-family:Arial;padding:16px"><h2>Email check</h2><table cellpadding="8" border="1" style="border-collapse:collapse;font-size:14px">';

row(true, "Email service chosen in mail_config.php", MAIL_PROVIDER);
row(otpConfigured(), "Sender details are filled in (not the placeholders)");

if (MAIL_PROVIDER === "script") {
    $target = ADMIN_OTP_EMAIL;
    row(ADMIN_OTP_EMAIL !== "", "ADMIN_OTP_EMAIL is set (your own Gmail, to receive the test)", ADMIN_OTP_EMAIL);
    row(strpos(SCRIPT_URL, "https://script.google.com/") === 0, "SCRIPT_URL looks right (starts with https://script.google.com/)");
    row(function_exists("curl_init"), "Server has cURL");
    $fp = @stream_socket_client("ssl://script.google.com:443", $en, $es, 8);
    row((bool)$fp, "Server can reach Google", $fp ? "connected" : $es);
    if ($fp) { fclose($fp); }
} elseif (MAIL_PROVIDER === "brevo") {
    $target = BREVO_SENDER_EMAIL;
    row(function_exists("curl_init") || ini_get("allow_url_fopen"), "Server can make web requests (cURL)");
    $fp = @stream_socket_client("ssl://api.brevo.com:443", $en, $es, 8);
    row((bool)$fp, "Server can reach Brevo", $fp ? "connected" : $es);
    if ($fp) { fclose($fp); }
} else {
    $target = SMTP_USER;
    $pass = str_replace(" ", "", SMTP_PASS);
    row(strlen($pass) === 16, "SMTP_PASS is a 16-letter App Password", "Length: " . strlen($pass));
    row(extension_loaded("openssl"), "OpenSSL available");
    foreach ([465 => "ssl://", 587 => "tcp://"] as $port => $scheme) {
        $fp = @stream_socket_client($scheme . SMTP_HOST . ":" . $port, $en, $es, 8);
        row((bool)$fp, "Can connect to Gmail on port " . $port, $fp ? "connected" : "blocked: " . $es);
        if ($fp) { fclose($fp); }
    }
}

echo '</table>';

if (isset($_POST["send"]) && $target === "") {
    echo '<p style="color:#d11c23;font-weight:bold">Set ADMIN_OTP_EMAIL in mail_config.php to your Gmail first.</p>';
} elseif (isset($_POST["send"])) {
    echo '<h3>Sending a test email to ' . htmlspecialchars($target) . ' ...</h3>';
    $err = "";
    list($html, $text) = otpEmailBody("Test", "123456", "register");
    if (smtpSend($target, "Barangay Mabuhay test email", $html, $text, $err)) {
        echo '<p style="color:#137a4b;font-weight:bold">Sent! Check the inbox (and Spam) of ' . htmlspecialchars($target) . '.</p>';
    } else {
        echo '<p style="color:#d11c23;font-weight:bold">Failed: ' . htmlspecialchars($err) . '</p>';
    }
}

echo '<form method="POST" style="margin-top:16px"><button name="send" value="1" style="padding:12px 20px;font-size:16px">Send test email</button></form>';
echo '<p style="color:#5a6683">Delete test_mail.php when you are done.</p></body>';
