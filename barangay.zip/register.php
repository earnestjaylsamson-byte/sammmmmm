
<?php
require_once __DIR__ . "/config.php";

$mailer_missing =
    !file_exists(__DIR__ . "/mailer.php") ||
    !file_exists(__DIR__ . "/mail_config.php");

if (!$mailer_missing) {
    require_once __DIR__ . "/mailer.php";
}

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$message = "";
$message_type = "";
$errors = [];

$name = "";
$email = "";
$password = "";
$confirm_password = "";

function registerBadField($errors, $key) {
    return isset($errors[$key]) ? "invalid" : "";
}

function registerFieldError($errors, $key) {
    if (!isset($errors[$key])) {
        return "";
    }

    return '<div class="field-error">' .
        htmlspecialchars($errors[$key], ENT_QUOTES, "UTF-8") .
        '</div>';
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $name = trim($_POST["name"] ?? "");
    $email = strtolower(trim($_POST["email"] ?? ""));
    $password = $_POST["password"] ?? "";
    $confirm_password = $_POST["confirm_password"] ?? "";

    // Validate full name.
    if ($name === "") {
        $errors["name"] = "Full name is required.";
    } elseif (strlen($name) > 150) {
        $errors["name"] = "Full name is too long.";
    }

    // Validate email.
    if ($email === "") {
        $errors["email"] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors["email"] = "Please enter a valid email address.";
    } elseif (strlen($email) > 254) {
        $errors["email"] = "Email address is too long.";
    }

    // Validate password.
    if ($password === "") {
        $errors["password"] = "Password is required.";
    } elseif (strlen($password) < 6) {
        $errors["password"] = "Password must be at least 6 characters.";
    } elseif (strlen($password) > 4096) {
        $errors["password"] = "Password is too long.";
    }

    if ($confirm_password === "") {
        $errors["confirm_password"] = "Please confirm your password.";
    } elseif ($password !== $confirm_password) {
        $errors["confirm_password"] = "Passwords do not match.";
    }

    if (empty($errors)) {

        try {
            $check = $conn->prepare(
                "SELECT id FROM users WHERE email = ? LIMIT 1"
            );

            if (!$check) {
                throw new Exception("Could not prepare the email check.");
            }

            $check->bind_param("s", $email);

            if (!$check->execute()) {
                $check->close();
                throw new Exception("Could not check the email address.");
            }

            $result = $check->get_result();
            $email_exists = $result && $result->num_rows > 0;
            $check->close();

            if ($email_exists) {

                $errors["email"] =
                    "This email is already registered. Please log in.";

            } elseif ($mailer_missing) {

                $message =
                    "Email verification files are missing. Upload mailer.php " .
                    "and mail_config.php to the same folder as register.php.";
                $message_type = "error";

            } elseif (!defined("OTP_ENABLED") || !OTP_ENABLED) {

                // Only use this branch if email verification has deliberately
                // been disabled in mail_config.php.
                $hashed_password = password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );

                if (createResident(
                    $conn,
                    $name,
                    $email,
                    $hashed_password,
                    $create_error
                )) {
                    header("Location: login.php?registered=1");
                    exit;
                }

                $message = $create_error ?: "Registration failed.";
                $message_type = "error";

            } elseif (
                !otpConfigured() &&
                !OTP_DEMO_MODE
            ) {

                $message =
                    "Email verification is not configured correctly. " .
                    "Please check mail_config.php.";
                $message_type = "error";

            } else {

                $hashed_password = password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );

                $mail_error = null;

                if (startRegistrationVerification(
                    $name,
                    $email,
                    $hashed_password,
                    $mail_error
                )) {
                    // The account is not created until the code is verified.
                    header("Location: verify_email.php");
                    exit;
                }

                $mail_error = trim((string)$mail_error);

                error_log(
                    "Barangay Mabuhay registration email failure: " .
                    ($mail_error !== "" ? $mail_error : "Unknown mailer error")
                );

                $message =
                    "We couldn't send the verification code. " .
                    "Please try again later.";

                // Temporarily enable SMTP_DEBUG in mail_config.php
                // to display the specific mailer error during testing.
                if (
                    defined("SMTP_DEBUG") &&
                    SMTP_DEBUG &&
                    $mail_error !== ""
                ) {
                    $message .= " Details: " . $mail_error;
                }

                $message_type = "error";
            }

        } catch (Throwable $e) {

            error_log(
                "Barangay Mabuhay registration error: " . $e->getMessage()
            );

            $message =
                "We couldn't process your registration right now. " .
                "Please try again later.";

            $message_type = "error";
        }
    }

    // Never refill passwords into the page after submission.
    $password = "";
    $confirm_password = "";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Register - Barangay Mabuhay</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="stylesheet" href="style.css?v=<?= @filemtime(__DIR__ . '/style.css') ?>">
<script src="form.js?v=<?= @filemtime(__DIR__ . '/form.js') ?>" defer></script>
</head>

<body>

<?php include __DIR__ . "/nav.php"; ?>

<section class="register-section">
<div class="register-box">

<h1>Create Account</h1>
<p class="subtitle">Register for your Barangay Mabuhay account</p>

<?php if ($message !== ""): ?>
<div class="message <?= htmlspecialchars($message_type, ENT_QUOTES, 'UTF-8') ?>" role="alert">
<?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?>
</div>
<?php endif; ?>

<form method="POST" action="register.php" novalidate data-validate>

<div class="form-group">
<label for="name">Full Name</label>
<input
    type="text"
    id="name"
    name="name"
    placeholder="Enter your full name"
    data-label="Full name"
    autocomplete="name"
    required
    class="<?= registerBadField($errors, 'name') ?>"
    value="<?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?>"
>
<?= registerFieldError($errors, 'name') ?>
</div>

<div class="form-group">
<label for="email">Email Address</label>
<input
    type="email"
    id="email"
    name="email"
    placeholder="Enter your email"
    data-rule="email"
    data-label="Email"
    autocomplete="email"
    required
    class="<?= registerBadField($errors, 'email') ?>"
    value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>"
>
<?= registerFieldError($errors, 'email') ?>
</div>

<div class="form-group">
<label for="password">Password</label>
<input
    type="password"
    id="password"
    name="password"
    placeholder="Create a password"
    data-rule="min:6"
    data-label="Password"
    autocomplete="new-password"
    required
    class="<?= registerBadField($errors, 'password') ?>"
>
<?= registerFieldError($errors, 'password') ?>
</div>

<div class="form-group">
<label for="confirm_password">Confirm Password</label>
<input
    type="password"
    id="confirm_password"
    name="confirm_password"
    placeholder="Confirm your password"
    data-rule="match:#password"
    data-label="Confirmation"
    autocomplete="new-password"
    required
    class="<?= registerBadField($errors, 'confirm_password') ?>"
>
<?= registerFieldError($errors, 'confirm_password') ?>
</div>

<button type="submit" class="register-btn">Create Account</button>

</form>

<div class="login-link">
Already have an account?
<a href="login.php">Login here</a>
</div>

</div>
</section>

</body>
</html>
