<?php

require_once "config.php";
requireAdmin();
ensureUserColumns($conn);

function one($conn, $sql) {
    $r = $conn->query($sql);
    return $r ? (int)$r->fetch_assoc()["c"] : 0;
}

$total_users        = one($conn, "SELECT COUNT(*) AS c FROM users WHERE role = 'resident'");
$total_requests     = one($conn, "SELECT COUNT(*) AS c FROM document_requests");
$pending_requests   = one($conn, "SELECT COUNT(*) AS c FROM document_requests WHERE status = 'Pending'");
$completed_requests = one($conn, "SELECT COUNT(*) AS c FROM document_requests WHERE status = 'Completed'");
$pending_residents  = one($conn, "SELECT COUNT(*) AS c FROM users WHERE role = 'resident' AND verification_status = 'Pending'");

$counts = [];
$res = $conn->query("SELECT document_type, COUNT(*) AS total, SUM(status = 'Pending') AS pending FROM document_requests GROUP BY document_type");
if ($res) { while ($r = $res->fetch_assoc()) { $counts[$r["document_type"]] = $r; } }

$types = array_keys(documentCatalog());
foreach (array_keys($counts) as $t) {
    if (!in_array($t, $types, true)) { $types[] = $t; }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Admin Dashboard - Barangay Mabuhay</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="stylesheet" href="style.css?v=<?= @filemtime(__DIR__ . '/style.css') ?>">
</head>

<body>

<?php include "nav.php"; ?>

<div class="container">

    <h1 class="page-title">Admin Dashboard</h1>

    <div class="stats">
        <div class="stat-card"><h3>Residents</h3><div class="stat-number"><?= $total_users ?></div></div>
        <div class="stat-card"><h3>Total Requests</h3><div class="stat-number"><?= $total_requests ?></div></div>
        <div class="stat-card"><h3>Pending Requests</h3><div class="stat-number"><?= $pending_requests ?></div></div>
        <div class="stat-card"><h3>Completed</h3><div class="stat-number"><?= $completed_requests ?></div></div>
    </div>

    <?php if ($pending_residents > 0): ?>
        <div class="attention">
            <div>
                <strong><?= $pending_residents ?> resident<?= $pending_residents === 1 ? "" : "s" ?> waiting for residency verification</strong>
                <p>Check their ID and address to confirm they live in Barangay Mabuhay.</p>
            </div>
            <a href="admin_residents.php?filter=Pending" class="btn btn-sm">Review now</a>
        </div>
    <?php endif; ?>

    <div class="section-head">
        <h2>Requests by document</h2>
        <p>Open a document to see only that kind of request.</p>
    </div>

    <div class="doc-grid">
        <?php foreach ($types as $t): $total = (int)($counts[$t]["total"] ?? 0); $pend = (int)($counts[$t]["pending"] ?? 0); ?>
            <a class="doc-card" href="admin_requests.php?type=<?= urlencode($t) ?>">
                <h3><?= htmlspecialchars($t) ?></h3>
                <div class="doc-meta">
                    <div class="doc-total"><?= $total ?><small>Total</small></div>
                    <span class="doc-pending<?= $pend === 0 ? " none" : "" ?>"><?= $pend ?> pending</span>
                </div>
            </a>
        <?php endforeach; ?>
    </div>

    <div class="actions">
        <a href="admin_requests.php" class="btn">All Requests</a>
        <a href="admin_residents.php" class="btn btn-light">Resident Verification</a>
    </div>

</div>

</body>
</html>
