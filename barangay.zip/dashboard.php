<?php
require_once "config.php";
requireLogin();

$user_id = $_SESSION["user_id"];

$stmt = $conn->prepare("SELECT COUNT(*) AS total FROM document_requests WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$total_requests = $stmt->get_result()->fetch_assoc()["total"];

$stmt = $conn->prepare("SELECT COUNT(*) AS total FROM document_requests WHERE user_id = ? AND status = 'Completed'");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$completed = $stmt->get_result()->fetch_assoc()["total"];

$stmt = $conn->prepare("SELECT COUNT(*) AS total FROM document_requests WHERE user_id = ? AND status NOT IN ('Completed','Rejected')");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$pending = $stmt->get_result()->fetch_assoc()["total"];

$vstatus = isAdminRole($_SESSION["role"] ?? "") ? "Verified" : getVerificationStatus($conn, $user_id, true);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard - Barangay Mabuhay</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="icon" type="image/png" href="favicon.png">
<link rel="stylesheet" href="style.css?v=<?= @filemtime(__DIR__ . '/style.css') ?>">
</head>

<body>

<?php include "nav.php"; ?>

<div class="container">

    <div class="welcome">
        <h1>Welcome, <?php echo htmlspecialchars($_SESSION["user_name"]); ?>!</h1>
        <p>Manage your barangay document requests through Barangay Mabuhay.</p>
    </div>

    <?php if ($vstatus !== "Verified"): ?>
        <div class="attention">
            <div>
                <?php if ($vstatus === "Pending"): ?>
                    <strong>Your residency verification is under review</strong>
                    <p>You can request documents as soon as the barangay approves it.</p>
                <?php else: ?>
                    <strong>Verify that you live in Barangay Mabuhay</strong>
                    <p>This is required before you can request any document.</p>
                <?php endif; ?>
            </div>
            <a href="verify_residency.php" class="btn btn-sm"><?= $vstatus === "Pending" ? "View status" : "Verify now" ?></a>
        </div>
    <?php endif; ?>

    <div class="cards">

        <div class="card">
            <h3>Total Requests</h3>
            <div class="number"><?php echo $total_requests; ?></div>
        </div>

        <div class="card">
            <h3>Pending Requests</h3>
            <div class="number"><?php echo $pending; ?></div>
        </div>

        <div class="card">
            <h3>Completed</h3>
            <div class="number"><?php echo $completed; ?></div>
        </div>

    </div>

    <div class="actions">
        <a href="request.php" class="btn">Request a Document</a>
        <a href="my_requests.php" class="btn btn-light">View My Requests</a>
    </div>

</div>

</body>
</html>