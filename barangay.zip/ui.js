// Adds a colour class to every status pill based on its text (e.g. "Pending" -> status-pending)
document.querySelectorAll('.status').forEach(function (el) {
  var s = el.textContent.trim().toLowerCase().replace(/[^a-z]+/g, '-');
  if (s) el.classList.add('status-' + s);
});

// Live search (and optional status filter) for tables
document.querySelectorAll('[data-filter-table]').forEach(function (input) {
  var id = input.getAttribute('data-filter-table');
  var table = document.getElementById(id);
  if (!table || !table.tBodies[0]) return;
  var select = document.querySelector('[data-filter-status="' + id + '"]');
  var rows = Array.prototype.slice.call(table.tBodies[0].rows);
  var cols = table.tHead ? table.tHead.rows[0].cells.length : 1;
  var empty = document.createElement('tr');
  empty.hidden = true;
  empty.innerHTML = '<td colspan="' + cols + '" style="text-align:center;color:#5a6683">No matching results.</td>';
  table.tBodies[0].appendChild(empty);
  function apply() {
    var q = input.value.trim().toLowerCase();
    var st = select ? select.value.toLowerCase() : '';
    var shown = 0;
    rows.forEach(function (r) {
      var ok = (!q || r.textContent.toLowerCase().indexOf(q) > -1) &&
               (!st || (r.getAttribute('data-status') || '').toLowerCase() === st);
      r.hidden = !ok;
      if (ok) shown++;
    });
    empty.hidden = shown > 0;
  }
  input.addEventListener('input', apply);
  if (select) select.addEventListener('change', apply);
});
