<?php
// Shows a resident's uploaded ID / proof of residency to ADMINS only.
require_once "config.php";
requireAdmin();

$id = intval($_GET["id"] ?? 0);

$stmt = $conn->prepare("SELECT id_file FROM users WHERE id = ? LIMIT 1");
$stmt->bind_param("i", $id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();

$file = basename($row["id_file"] ?? "");
$path = __DIR__ . "/uploads/ids/" . $file;

if ($file === "" || !is_file($path)) {
    http_response_code(404);
    exit("File not found.");
}

$finfo = new finfo(FILEINFO_MIME_TYPE);

header("Content-Type: " . $finfo->file($path));
header("Content-Disposition: inline; filename=\"" . $file . "\"");
header("X-Content-Type-Options: nosniff");
header("Content-Length: " . filesize($path));

readfile($path);
